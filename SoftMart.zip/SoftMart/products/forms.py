from django import forms
from django.forms import inlineformset_factory

from .models import SoftProduct, SoftProductFeature


class SoftProductForm(forms.ModelForm):
    class Meta:
        model = SoftProduct
        fields = ('title', 'short_description', 'description', 'price', 'image', 'file', 'status')
        widgets = {
            'description': forms.Textarea(attrs={'rows': 5, 'placeholder': 'Full product description...'}),
            'short_description': forms.TextInput(attrs={'placeholder': 'Brief one-line description'}),
            'price': forms.NumberInput(attrs={'min': '0', 'step': '0.01'}),
        }

    def clean_price(self):
        price = self.cleaned_data.get('price')
        if price is not None and price < 0:
            raise forms.ValidationError('Price cannot be negative.')
        return price


SoftProductFeatureFormSet = inlineformset_factory(
    SoftProduct,
    SoftProductFeature,
    fields=('text',),
    extra=3,
    can_delete=True,
    widgets={
        'text': forms.TextInput(attrs={'placeholder': 'e.g. Works on Windows 10/11, Lifetime license'}),
    },
)
