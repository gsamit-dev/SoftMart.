import os
import zipfile

from PIL import Image, ImageDraw, ImageFont

from django.core.management.base import BaseCommand

from accounts.models import User
from catalog.models import Category
from products.models import SoftProduct, SoftProductFeature

PRODUCTS = [
    {
        'title': 'TaskFlow Pro',
        'short_description': 'Smart task & project manager for teams and freelancers.',
        'description': 'TaskFlow Pro is a powerful productivity tool that helps you manage tasks, set deadlines, and collaborate with your team in real time. Perfect for freelancers and small businesses.',
        'price': '1299',
        'category': 'Productivity',
        'color': (67, 97, 238),
        'icon': 'TF',
        'features': ['Unlimited tasks & projects', 'Team collaboration tools', 'Deadline & reminder alerts', 'Windows 10/11 support', 'Lifetime license included'],
    },
    {
        'title': 'ShieldGuard Antivirus',
        'short_description': 'Real-time protection against viruses, malware & ransomware.',
        'description': 'ShieldGuard provides enterprise-grade security for your PC. Lightweight engine with real-time scanning, ransomware shield, and automatic updates.',
        'price': '1899',
        'category': 'Security',
        'color': (34, 139, 87),
        'icon': 'SG',
        'features': ['Real-time virus scanning', 'Ransomware protection', 'Firewall manager', '1 Year license', 'Auto virus definition updates'],
    },
    {
        'title': 'PixelCraft Studio',
        'short_description': 'Professional image editor and graphic design suite.',
        'description': 'PixelCraft Studio is a full-featured design tool for creating logos, banners, social media graphics and UI mockups. Supports layers, filters, and 500+ templates.',
        'price': '2499',
        'category': 'Design',
        'color': (190, 50, 140),
        'icon': 'PC',
        'features': ['500+ design templates', 'Layer-based editing', 'Export PNG, JPG, SVG, PDF', 'Windows & Mac support', 'Free updates for 1 year'],
    },
    {
        'title': 'CodeSnap IDE',
        'short_description': 'Lightweight code editor with Git support & smart autocomplete.',
        'description': 'CodeSnap IDE is built for developers who want speed and simplicity. Supports 30+ programming languages with syntax highlighting, Git integration, and a plugin marketplace.',
        'price': '1599',
        'category': 'Developer Tools',
        'color': (30, 120, 200),
        'icon': 'CS',
        'features': ['30+ language support', 'Built-in Git integration', 'Smart autocomplete (AI)', 'Dark & light themes', 'Plugin marketplace'],
    },
    {
        'title': 'CleanDrive Optimizer',
        'short_description': 'One-click PC cleaner, optimizer and startup manager.',
        'description': 'CleanDrive removes junk files, fixes registry errors, manages startup programs, and speeds up your Windows PC in minutes. Scheduled auto-clean keeps your PC always fast.',
        'price': '999',
        'category': 'Utilities',
        'color': (200, 120, 30),
        'icon': 'CD',
        'features': ['Junk file cleaner', 'Registry optimizer', 'Startup manager', 'Disk space analyzer', 'Scheduled auto-clean'],
    },
    {
        'title': 'NoteVault',
        'short_description': 'Encrypted note-taking app with markdown & cloud sync.',
        'description': 'NoteVault keeps your notes safe with AES-256 encryption. Write in markdown, organize with tags, and sync across all your devices seamlessly.',
        'price': '699',
        'category': 'Productivity',
        'color': (100, 60, 200),
        'icon': 'NV',
        'features': ['AES-256 encryption', 'Markdown editor', 'Cloud sync across devices', 'Offline mode', 'Windows & Mac support'],
    },
    {
        'title': 'StreamCast Pro',
        'short_description': 'Professional screen recorder and live streaming software.',
        'description': 'StreamCast Pro lets you record your screen in 4K, add overlays, and stream live to YouTube, Twitch, and Facebook simultaneously. Perfect for content creators.',
        'price': '2199',
        'category': 'Utilities',
        'color': (200, 40, 60),
        'icon': 'SP',
        'features': ['4K screen recording', 'Multi-platform streaming', 'Custom overlays & scenes', 'Audio mixer built-in', 'No watermark'],
    },
    {
        'title': 'DataVault Backup',
        'short_description': 'Automated cloud & local backup solution for Windows.',
        'description': 'DataVault Backup automatically backs up your important files to local drives or cloud storage. Schedule backups, restore with one click, and never lose data again.',
        'price': '1499',
        'category': 'Utilities',
        'color': (20, 150, 160),
        'icon': 'DV',
        'features': ['Automated scheduled backups', 'Cloud & local storage support', 'One-click restore', 'File versioning (30 days)', 'AES-256 encrypted backups'],
    },
]


def make_image(path, text, bg_color):
    """Generate a 400x300 product thumbnail using Pillow."""
    img = Image.new('RGB', (400, 300), color=bg_color)
    draw = ImageDraw.Draw(img)

    # gradient overlay — draw darker strips at bottom
    for i in range(100):
        alpha = int(i * 1.5)
        r = max(0, bg_color[0] - alpha // 3)
        g = max(0, bg_color[1] - alpha // 3)
        b = max(0, bg_color[2] - alpha // 3)
        draw.rectangle([(0, 200 + i), (400, 201 + i)], fill=(r, g, b))

    # big icon letters in center
    try:
        font_big = ImageFont.truetype("arial.ttf", 80)
        font_small = ImageFont.truetype("arial.ttf", 18)
    except Exception:
        font_big = ImageFont.load_default()
        font_small = ImageFont.load_default()

    # white circle background
    draw.ellipse([(140, 60), (260, 180)], fill=(255, 255, 255, 40))
    draw.ellipse([(145, 65), (255, 175)], fill=(255, 255, 255, 60))

    # icon text
    bbox = draw.textbbox((0, 0), text, font=font_big)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    draw.text(((400 - tw) / 2, (240 - th) / 2 - 20), text, fill=(255, 255, 255), font=font_big)

    # bottom label
    draw.rectangle([(0, 260), (400, 300)], fill=(0, 0, 0, 80))
    label = 'SoftMart'
    bbox2 = draw.textbbox((0, 0), label, font=font_small)
    lw = bbox2[2] - bbox2[0]
    draw.text(((400 - lw) / 2, 272), label, fill=(200, 210, 255), font=font_small)

    img.save(path, 'PNG')


class Command(BaseCommand):
    help = 'Seed demo products with images'

    def handle(self, *args, **kwargs):
        seller = User.objects.filter(role='seller').first()
        if not seller:
            self.stdout.write(self.style.ERROR('No seller found.'))
            return

        img_dir = os.path.join('media', 'soft_products', 'images')
        file_dir = os.path.join('media', 'soft_products', 'files')
        os.makedirs(img_dir, exist_ok=True)
        os.makedirs(file_dir, exist_ok=True)

        for data in PRODUCTS:
            if SoftProduct.objects.filter(title=data['title']).exists():
                self.stdout.write(f"Skip: {data['title']}")
                continue

            cat, _ = Category.objects.get_or_create(
                name=data['category'],
                defaults={'slug': data['category'].lower().replace(' ', '-'), 'is_active': True},
            )

            # generate image
            img_name = data['title'].replace(' ', '_') + '.png'
            img_path = os.path.join(img_dir, img_name)
            make_image(img_path, data['icon'], data['color'])

            # generate zip
            zip_name = data['title'].replace(' ', '_') + '_v1.0.zip'
            zip_path = os.path.join(file_dir, zip_name)
            with zipfile.ZipFile(zip_path, 'w') as zf:
                zf.writestr('README.txt', f"{data['title']}\n{data['short_description']}\n\nFeatures:\n" + '\n'.join(f'- {f}' for f in data['features']))
                zf.writestr('install.txt', 'Run setup.exe to install. Requires Windows 10 or later.')
                zf.writestr('license.txt', f'Licensed to: SoftMart Customer\nProduct: {data["title"]}\nLicense: Lifetime')

            p = SoftProduct(
                seller=seller,
                title=data['title'],
                short_description=data['short_description'],
                description=data['description'],
                price=data['price'],
                category=cat,
                status='published',
            )
            p.image.name = f'soft_products/images/{img_name}'
            p.file.name = f'soft_products/files/{zip_name}'
            p.save()

            for feat in data['features']:
                SoftProductFeature.objects.create(product=p, text=feat)

            self.stdout.write(self.style.SUCCESS(f'Created: {p.title} | BDT {p.price}'))

        self.stdout.write(self.style.SUCCESS('Done!'))
