import random
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from accounts.models import User
from products.models import SoftProduct, SoftProductPurchase


class Command(BaseCommand):
    help = 'Seed demo sales for seller dashboard'

    def handle(self, *args, **kwargs):
        seller = User.objects.filter(role='seller').first()
        if not seller:
            self.stdout.write(self.style.ERROR('No seller found.'))
            return

        products = list(SoftProduct.objects.filter(seller=seller))
        if not products:
            self.stdout.write(self.style.ERROR('No products found. Run seed_demo_products first.'))
            return

        # create demo buyer accounts if not exist
        buyers = []
        demo_buyers = [
            ('Rahim Uddin', 'rahim@demo.com'),
            ('Karim Hossain', 'karim@demo.com'),
            ('Nasrin Akter', 'nasrin@demo.com'),
            ('Sumon Ahmed', 'sumon@demo.com'),
            ('Fatema Begum', 'fatema@demo.com'),
        ]
        for name, email in demo_buyers:
            user, created = User.objects.get_or_create(
                email=email,
                defaults={
                    'username': email.split('@')[0],
                    'full_name': name,
                    'role': 'customer',
                    'is_email_verified': True,
                    'account_status': 'active',
                }
            )
            if created:
                user.set_password('demo1234')
                user.save()
            buyers.append(user)

        # create demo purchases spread over last 30 days
        created_count = 0
        for i in range(25):
            buyer = random.choice(buyers)
            product = random.choice(products)
            days_ago = random.randint(0, 30)
            purchase_date = timezone.now() - timedelta(days=days_ago)

            purchase, created = SoftProductPurchase.objects.get_or_create(
                buyer=buyer,
                product=product,
                defaults={
                    'amount_paid': product.price,
                    'is_paid': True,
                }
            )
            if created:
                # manually set created_at via update
                SoftProductPurchase.objects.filter(pk=purchase.pk).update(
                    created_at=purchase_date,
                    is_paid=True,
                )
                created_count += 1

        self.stdout.write(self.style.SUCCESS(f'Created {created_count} demo sales across {len(buyers)} buyers.'))
