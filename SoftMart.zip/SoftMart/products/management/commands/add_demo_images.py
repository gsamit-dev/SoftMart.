import os
import struct
import zlib

from django.core.management.base import BaseCommand

from products.models import SoftProduct

COLORS = {
    'taskflow':   (94, 123, 255),
    'shieldguard': (80, 180, 120),
    'pixelcraft': (220, 80, 160),
    'codesnap':   (80, 160, 220),
    'cleandrive': (220, 140, 50),
}
DEFAULT_COLOR = (100, 100, 200)


def _make_png(width, height, r, g, b):
    def chunk(name, data):
        c = zlib.crc32(name + data) & 0xFFFFFFFF
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', c)
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0)
    row = b'\x00' + bytes([r, g, b] * width)
    idat = zlib.compress(row * height)
    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', ihdr)
    png += chunk(b'IDAT', idat)
    png += chunk(b'IEND', b'')
    return png


class Command(BaseCommand):
    help = 'Add placeholder images to demo products'

    def handle(self, *args, **kwargs):
        media_dir = os.path.join('media', 'soft_products', 'images')
        os.makedirs(media_dir, exist_ok=True)

        for product in SoftProduct.objects.all():
            if product.image:
                self.stdout.write(f'Skip: {product.title}')
                continue

            key = product.title.lower().replace(' ', '')
            color = next((v for k, v in COLORS.items() if k in key), DEFAULT_COLOR)
            r, g, b = color

            filename = f'{product.slug}_thumb.png'
            filepath = os.path.join(media_dir, filename)
            with open(filepath, 'wb') as f:
                f.write(_make_png(400, 300, r, g, b))

            product.image = f'soft_products/images/{filename}'
            product.save(update_fields=['image'])
            self.stdout.write(self.style.SUCCESS(f'Image added: {product.title}'))
