import hashlib
import hmac
import uuid

from django.conf import settings
from django.db import models
from django.utils.text import slugify


class SoftProduct(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('published', 'Published'),
        ('archived', 'Archived'),
    ]

    seller = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='soft_products',
    )
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True, blank=True)
    short_description = models.CharField(max_length=300, blank=True)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    category = models.ForeignKey(
        'catalog.Category',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='soft_products',
    )
    image = models.ImageField(upload_to='soft_products/images/', blank=True, null=True)
    file = models.FileField(upload_to='soft_products/files/')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='published')
    rating = models.FloatField(default=0)
    rating_count = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def _auto_detect_category(self):
        """Match title+description keywords against active Category names."""
        from catalog.models import Category
        text = f'{self.title} {self.short_description} {self.description}'.lower()
        for category in Category.objects.filter(is_active=True):
            if category.name.lower() in text:
                return category
        # fallback: return first active category if any exists
        return Category.objects.filter(is_active=True).first()

    def save(self, *args, **kwargs):
        # auto slug
        if not self.slug:
            base_slug = slugify(self.title) or 'product'
            self.slug = base_slug
            suffix = 2
            while SoftProduct.objects.exclude(pk=self.pk).filter(slug=self.slug).exists():
                self.slug = f'{base_slug[:45]}-{suffix}'
                suffix += 1
        # auto category only if not set by seller
        if not self.category_id:
            self.category = self._auto_detect_category()
        super().save(*args, **kwargs)


class SoftProductFeature(models.Model):
    product = models.ForeignKey(SoftProduct, on_delete=models.CASCADE, related_name='features')
    text = models.CharField(max_length=255)

    def __str__(self):
        return self.text


class SoftProductPurchase(models.Model):
    buyer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='soft_purchases',
    )
    product = models.ForeignKey(SoftProduct, on_delete=models.CASCADE, related_name='purchases')
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2)
    is_paid = models.BooleanField(default=False)
    license_key_hash = models.CharField(max_length=64, blank=True, db_index=True)
    payment_session_id = models.CharField(max_length=255, blank=True)
    risk_score = models.PositiveSmallIntegerField(default=0)
    risk_level = models.CharField(max_length=10, choices=[('low', 'Low'), ('review', 'Review'), ('high', 'High')], default='low')
    risk_reasons = models.JSONField(default=list, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('buyer', 'product')

    def __str__(self):
        return f'{self.buyer.email} -> {self.product.title}'

    def generate_license_key(self):
        if not self.license_key_hash:
            key = self._derived_license_key()
            self.license_key_hash = hashlib.sha256(key.encode('utf-8')).hexdigest()
            self.save(update_fields=['license_key_hash'])
            return key
        return None

    def _derived_license_key(self):
        from django.conf import settings
        digest = hmac.new(
            settings.SECRET_KEY.encode('utf-8'),
            f'softmart-license:{self.pk}'.encode('utf-8'),
            hashlib.sha256,
        ).hexdigest()[:32]
        return str(uuid.UUID(hex=digest)).upper()

    @property
    def license_key_display(self):
        if not self.pk or not self.license_key_hash:
            return ''
        key = self._derived_license_key()
        expected = hashlib.sha256(key.encode('utf-8')).hexdigest()
        return key if hmac.compare_digest(expected, self.license_key_hash) else ''


class LicenseActivation(models.Model):
    purchase = models.OneToOneField(SoftProductPurchase, on_delete=models.CASCADE, related_name='activation')
    device_fingerprint_hash = models.CharField(max_length=64, blank=True)
    pending_device_fingerprint_hash = models.CharField(max_length=64, blank=True)
    activated_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def is_active(self):
        from django.utils import timezone
        return bool(self.device_fingerprint_hash and self.expires_at and self.expires_at > timezone.now())

    def __str__(self):
        return f'{self.purchase} device license'


class SoftProductReview(models.Model):
    product = models.ForeignKey(SoftProduct, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='soft_reviews')
    rating = models.PositiveSmallIntegerField(default=5)
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('product', 'user')
        constraints = [
            models.CheckConstraint(condition=models.Q(rating__gte=1, rating__lte=5), name='soft_review_rating_1_to_5'),
        ]

    def __str__(self):
        return f'{self.user.email} rated {self.product.title}'
