from django.contrib import admin
from .models import LicenseActivation, SoftProduct, SoftProductFeature, SoftProductPurchase, SoftProductReview


class FeatureInline(admin.TabularInline):
    model = SoftProductFeature
    extra = 1


@admin.register(SoftProduct)
class SoftProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'seller', 'price', 'status', 'created_at')
    list_filter = ('status',)
    search_fields = ('title', 'seller__email')
    inlines = [FeatureInline]


@admin.register(SoftProductPurchase)
class SoftProductPurchaseAdmin(admin.ModelAdmin):
    list_display = ('buyer', 'product', 'amount_paid', 'is_paid', 'risk_score', 'risk_level', 'created_at')
    list_filter = ('is_paid', 'risk_level')
    readonly_fields = ('license_key_hash', 'risk_score', 'risk_level', 'risk_reasons')


@admin.register(SoftProductReview)
class SoftProductReviewAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'rating', 'created_at')
    list_filter = ('rating',)


@admin.register(LicenseActivation)
class LicenseActivationAdmin(admin.ModelAdmin):
    list_display = ('purchase', 'activated_at', 'expires_at', 'updated_at')
    search_fields = ('purchase__buyer__email', 'purchase__product__title')
    readonly_fields = ('purchase', 'device_fingerprint_hash', 'activated_at', 'expires_at', 'created_at', 'updated_at')
