import re
from difflib import SequenceMatcher
from datetime import timedelta

from django.db.models import Case, IntegerField, Value, When
from django.utils import timezone


def preferred_category_ids(user):
    if not user.is_authenticated:
        return []
    from orders.models import OrderItem, Review
    from .models import SoftProductPurchase, SoftProductReview

    categories = set(SoftProductPurchase.objects.filter(
        buyer=user, is_paid=True, product__category__isnull=False
    ).values_list('product__category_id', flat=True))
    categories.update(SoftProductReview.objects.filter(
        user=user, product__category__isnull=False
    ).values_list('product__category_id', flat=True))
    categories.update(OrderItem.objects.filter(
        order__user=user, order__status__in=['paid', 'completed'], product__category__isnull=False
    ).values_list('product__category_id', flat=True))
    categories.update(Review.objects.filter(
        user=user, product__category__isnull=False
    ).values_list('product__category_id', flat=True))
    return list(categories)


def personalize_queryset(queryset, user):
    category_ids = preferred_category_ids(user)
    if not category_ids:
        return queryset.order_by('-rating', '-rating_count', '-created_at')
    return queryset.annotate(
        _preference_rank=Case(
            When(category_id__in=category_ids, then=Value(0)),
            default=Value(1), output_field=IntegerField(),
        )
    ).order_by('_preference_rank', '-rating', '-rating_count', '-created_at')


def recommended_soft_products(user, limit=8):
    from .models import SoftProduct, SoftProductPurchase
    purchased_ids = SoftProductPurchase.objects.filter(buyer=user, is_paid=True).values_list('product_id', flat=True) if user.is_authenticated else []
    candidates = SoftProduct.objects.filter(status='published').exclude(id__in=purchased_ids).select_related('category')
    return personalize_queryset(candidates, user)[:limit]


def assess_soft_purchase_risk(purchase):
    from orders.models import Order
    from .models import SoftProductPurchase

    now = timezone.now()
    recent_soft = SoftProductPurchase.objects.filter(
        buyer=purchase.buyer, created_at__gte=now - timedelta(hours=1)
    ).exclude(pk=purchase.pk).count()
    recent_orders = Order.objects.filter(
        user=purchase.buyer, created_at__gte=now - timedelta(hours=1)
    ).count()
    cancellations = Order.objects.filter(
        user=purchase.buyer, status='cancelled', created_at__gte=now - timedelta(days=1)
    ).count()
    score, reasons = 0, []
    if recent_soft + recent_orders >= 4:
        score += 35
        reasons.append('Multiple checkout attempts in one hour')
    if cancellations >= 3:
        score += 30
        reasons.append('Repeated order cancellations in one day')
    if purchase.amount_paid >= 50000:
        score += 35
        reasons.append('Unusually high purchase amount')
    if purchase.buyer.created_at and purchase.buyer.created_at >= now - timedelta(hours=24):
        score += 15
        reasons.append('Recently created account')
    purchase.risk_score = min(score, 100)
    purchase.risk_level = 'high' if purchase.risk_score >= 60 else 'review' if purchase.risk_score >= 30 else 'low'
    purchase.risk_reasons = reasons
    purchase.save(update_fields=['risk_score', 'risk_level', 'risk_reasons'])
    return purchase


def analyze_review_sentiment(text):
    positive = {'good', 'great', 'excellent', 'amazing', 'love', 'useful', 'easy', 'fast', 'recommend', 'best', 'bhalo', 'valo', 'darun', 'chomotkar'}
    negative = {'bad', 'poor', 'broken', 'slow', 'bug', 'bugs', 'waste', 'hate', 'difficult', 'unusable', 'kharap', 'baje', 'somossa'}
    negations = {'not', 'never', 'no', 'dont', "don't", 'isnt', "isn't", 'na', 'nei'}
    words = re.findall(r"[\w']+", (text or '').lower(), flags=re.UNICODE)
    score = 0
    negate_next = 0
    for word in words:
        if word in negations:
            negate_next = 3
            continue
        sentiment = 1 if word in positive else -1 if word in negative else 0
        if sentiment:
            score += -sentiment if negate_next else sentiment
        if negate_next:
            negate_next -= 1
    if score > 0:
        label = 'Positive'
    elif score < 0:
        label = 'Negative'
    else:
        label = 'Neutral'
    return {'label': label, 'score': score}


_SUPPORT_FAQS = [
    ({'activate', 'activation', 'device', 'otp', 'authorize', 'license', 'license key', 'kibhabe', 'device'}, 'License activation: sign in with the email used for purchase, open the purchased software page, then choose Authorize this device. Enter the OTP sent to your email. A license can be active on one device for one year.'),
    ({'renew', 'renewal', 'expire', 'expired', 'validity', 'meyad', 'renew korte'}, 'Renewal: after your one-year license expires, open the same software on its authorized device and request a renewal OTP. Verify the code sent to your purchase email to renew for another year.'),
    ({'download', 'install', 'file', 'zip', 'download korte', 'install'}, 'Download: sign in with the purchasing account, authorize the device by email OTP, then use the Download button on the software page. Downloads stay locked until the license is active.'),
    ({'payment', 'pay', 'paid', 'bkash', 'card', 'sslcommerz', 'taka', 'tk', 'payment kaj'}, 'Payments use SSLCommerz. Choose Pay at checkout and complete payment on the SSLCommerz page. The order unlocks only after the transaction is validated. You can retry a failed payment from Orders.'),
    ({'login', 'account', 'password', 'email', 'otp', 'login korte', 'password reset'}, 'Account help: use your registered email to sign in. If you forgot your password, choose Forgot password on the login page. Email verification codes expire after five minutes.'),
    ({'search', 'category', 'recommend', 'software', 'khujte', 'search result'}, 'Search: use the search box and category, price and sorting filters. Recommendations and search ranking use your purchased and reviewed software categories.'),
    ({'review', 'rating', 'review dibo', 'rating dibo'}, 'Reviews: only verified purchasers can submit a rating and review from the product page. You can update your review later.'),
]


def answer_support_message(message):
    normalized = (message or '').strip().lower()
    words = set(re.findall(r"[\w']+", normalized, flags=re.UNICODE))
    best_answer, best_score = None, 0.0
    for terms, answer in _SUPPORT_FAQS:
        overlap = len(words & terms) / max(len(terms), 1)
        phrase = max((SequenceMatcher(None, normalized, term).ratio() for term in terms if len(term) > 3), default=0)
        score = overlap + phrase * 0.25
        if score > best_score:
            best_answer, best_score = answer, score
    if best_score < 0.16:
        return 'I could not confidently match that question. Please mention whether it is about your account, payment, download, license activation, or renewal.'
    return best_answer
