import mimetypes
import os
import uuid
import hashlib
import json
import re
from smtplib import SMTPException
from datetime import timedelta
from decimal import Decimal, InvalidOperation
from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import check_password, make_password
from django.core.mail import EmailMultiAlternatives
from django.db import transaction
from django.db.models import Avg, Count
from django.http import FileResponse, Http404, HttpResponseForbidden, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from django.conf import settings
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt

from catalog.models import Category
from .forms import SoftProductFeatureFormSet, SoftProductForm
from .models import SoftProduct, SoftProductPurchase, SoftProductReview
from .ai_services import analyze_review_sentiment, assess_soft_purchase_risk, personalize_queryset
from otp.models import OTP


def _device_fingerprint_hash(value):
    if not isinstance(value, str) or not 8 <= len(value.strip()) <= 512:
        return ''
    return hashlib.sha256(value.strip().encode('utf-8')).hexdigest()


def _send_license_otp(user, activation, purpose):
    now = timezone.now()
    if OTP.objects.filter(activation=activation, purpose=purpose, created_at__gte=now - timedelta(minutes=1)).exists():
        return None, 'Please wait one minute before requesting another license code.'
    OTP.objects.filter(activation=activation, is_used=False).update(is_used=True)
    code = OTP.generate_code()
    product_name = activation.purchase.product.title
    if purpose == 'device_renewal':
        subject = f'Renew your {product_name} license'
        intro = 'Enter this code to renew your license for one year on its authorized device.'
    else:
        subject = f'Authorize your {product_name} device'
        intro = 'Enter this code to authorize this device for your purchased software license.'
    try:
        EmailMultiAlternatives(
            subject=subject,
            body=f'{intro}\n\nYour verification code is {code}. It expires in 5 minutes. Do not share this code.',
            from_email=None,
            to=[user.email],
        ).send(fail_silently=False)
    except (SMTPException, OSError):
        return None, 'We could not send the verification email. Please try again later.'
    otp = OTP.objects.create(
        user=user, activation=activation, purpose=purpose, code=make_password(code),
        expires_at=now + timedelta(minutes=5),
    )
    return otp, None


# ---------- helpers ----------

def seller_required(view):
    @wraps(view)
    @login_required
    def wrapped(request, *args, **kwargs):
        if request.user.role != 'seller' and not request.user.is_staff:
            return HttpResponseForbidden('Seller access required.')
        return view(request, *args, **kwargs)
    return wrapped


# ---------- public views ----------

def product_list(request):
    products = SoftProduct.objects.filter(status='published').select_related('category')
    q = request.GET.get('q', '').strip()
    category_slug = request.GET.get('category', '').strip()
    if q:
        from django.db.models import Q
        products = products.filter(Q(title__icontains=q) | Q(short_description__icontains=q) | Q(description__icontains=q) | Q(category__name__icontains=q))
    if category_slug:
        products = products.filter(category__slug=category_slug)
    min_price = request.GET.get('min_price', '').strip()
    max_price = request.GET.get('max_price', '').strip()
    sort = request.GET.get('sort', 'recommended')
    try:
        value = Decimal(min_price) if min_price else None
        if value is not None and value.is_finite() and value >= 0:
            products = products.filter(price__gte=value)
    except InvalidOperation:
        min_price = ''
    try:
        value = Decimal(max_price) if max_price else None
        if value is not None and value.is_finite() and value >= 0:
            products = products.filter(price__lte=value)
    except InvalidOperation:
        max_price = ''
    ordering = {'newest': '-created_at', 'price_low': 'price', 'price_high': '-price', 'rating': '-rating'}
    if sort not in ordering and sort != 'recommended':
        sort = 'recommended'
    products = personalize_queryset(products, request.user) if sort == 'recommended' else products.order_by(ordering.get(sort, '-created_at'))
    categories = Category.objects.filter(is_active=True)
    return render(request, 'products/product_list.html', {
        'products': products,
        'q': q,
        'categories': categories,
        'active_category': category_slug,
        'min_price': min_price, 'max_price': max_price,
        'sort': sort,
    })


def product_detail(request, slug):
    product = get_object_or_404(SoftProduct, slug=slug, status='published')
    already_purchased = (
        request.user.is_authenticated
        and SoftProductPurchase.objects.filter(buyer=request.user, product=product, is_paid=True).exists()
    )
    purchase = None
    existing_review = None
    if request.user.is_authenticated and already_purchased:
        purchase = SoftProductPurchase.objects.filter(buyer=request.user, product=product, is_paid=True).first()
        existing_review = SoftProductReview.objects.filter(product=product, user=request.user).first()
    activation = None
    license_key_display = ''
    if purchase:
        from .models import LicenseActivation
        activation = LicenseActivation.objects.filter(purchase=purchase).first()
        # Rotate keys created before the hash-only scheme so buyers retain access.
        license_key_display = purchase._derived_license_key()
        current_hash = hashlib.sha256(license_key_display.encode('utf-8')).hexdigest()
        if purchase.license_key_hash != current_hash:
            purchase.license_key_hash = current_hash
            purchase.save(update_fields=['license_key_hash'])
    reviews = list(product.reviews.select_related('user').order_by('-created_at'))
    sentiment_counts = {'Positive': 0, 'Neutral': 0, 'Negative': 0}
    for review in reviews:
        review.sentiment_label = analyze_review_sentiment(review.comment)['label']
        sentiment_counts[review.sentiment_label] += 1
    return render(request, 'products/product_detail.html', {
        'product': product,
        'already_purchased': already_purchased,
        'purchase': purchase,
        'license_key_display': license_key_display,
        'can_review': already_purchased,
        'existing_review': existing_review,
        'reviews': reviews,
        'sentiment_counts': sentiment_counts,
        'activation': activation,
        'license_active': bool(activation and activation.is_active),
        'license_expired': bool(activation and activation.expires_at and activation.expires_at <= timezone.now()),
    })


# ---------- purchase / payment ----------

@login_required
def buy_product(request, slug):
    product = get_object_or_404(SoftProduct, slug=slug, status='published')
    purchase, _ = SoftProductPurchase.objects.get_or_create(
        buyer=request.user,
        product=product,
        defaults={'amount_paid': product.price, 'is_paid': False},
    )
    if purchase.is_paid:
        messages.info(request, 'You already purchased this product.')
        return redirect('products:download', slug=product.slug)
    return render(request, 'products/payment.html', {'product': product, 'purchase': purchase})


@login_required
@require_POST
def activate_device(request, slug):
    from .models import LicenseActivation
    product = get_object_or_404(SoftProduct, slug=slug, status='published')
    purchase = get_object_or_404(SoftProductPurchase, buyer=request.user, product=product, is_paid=True)
    raw_device_id = request.POST.get('device_id', '').strip()
    try:
        device_id = str(uuid.UUID(raw_device_id))
    except (ValueError, AttributeError):
        messages.error(request, 'Could not identify this browser. Enable browser storage and try again.')
        return redirect('products:detail', slug=slug)
    device_hash = hashlib.sha256(device_id.encode('utf-8')).hexdigest()
    activation, _ = LicenseActivation.objects.get_or_create(purchase=purchase)
    if activation.is_active and activation.device_fingerprint_hash == device_hash:
        messages.info(request, 'This device is already authorized until ' + activation.expires_at.strftime('%d %b %Y') + '.')
        return redirect('products:detail', slug=slug)

    purpose = 'device_renewal' if activation.device_fingerprint_hash == device_hash else 'device_activation'
    otp, error = _send_license_otp(request.user, activation, purpose)
    if error:
        messages.error(request, error)
        return redirect('products:detail', slug=slug)
    activation.pending_device_fingerprint_hash = device_hash
    activation.save(update_fields=['pending_device_fingerprint_hash', 'updated_at'])
    request.session['license_activation_id'] = activation.id
    request.session['license_otp_id'] = otp.id
    request.session['license_device_hash'] = device_hash
    request.session['license_otp_purpose'] = purpose
    messages.success(request, f'A verification code has been sent to {request.user.email}.')
    return redirect('products:verify_device_otp')


@login_required
def verify_device_otp(request):
    from .models import LicenseActivation
    activation_id = request.session.get('license_activation_id')
    otp_id = request.session.get('license_otp_id')
    device_hash = request.session.get('license_device_hash')
    purpose = request.session.get('license_otp_purpose')
    if not all((activation_id, otp_id, device_hash, purpose)):
        return redirect('products:list')
    activation = get_object_or_404(
        LicenseActivation.objects.select_related('purchase__product'),
        pk=activation_id, purchase__buyer=request.user, purchase__is_paid=True,
    )
    otp = get_object_or_404(OTP, pk=otp_id, user=request.user, activation=activation, purpose=purpose, is_used=False)
    if request.method == 'POST':
        code = request.POST.get('code', '').strip()
        if otp.expires_at <= timezone.now():
            messages.error(request, 'The code expired. Request a new one from the software page.')
        elif otp.attempts >= OTP.MAX_ATTEMPTS:
            messages.error(request, 'Too many attempts. Request a new code from the software page.')
        elif not re.fullmatch(r'\d{6}', code) or not check_password(code, otp.code):
            otp.attempts += 1
            otp.save(update_fields=['attempts'])
            messages.error(request, 'That code is incorrect.')
        else:
            with transaction.atomic():
                activation = LicenseActivation.objects.select_for_update().get(pk=activation.pk)
                if activation.pending_device_fingerprint_hash != device_hash:
                    messages.error(request, 'This device verification request is no longer valid.')
                    return redirect('products:detail', slug=activation.purchase.product.slug)
                if purpose == 'device_activation':
                    activation.device_fingerprint_hash = device_hash
                    activation.pending_device_fingerprint_hash = ''
                    activation.activated_at = timezone.now()
                    activation.expires_at = timezone.now() + timedelta(days=365)
                else:
                    if activation.device_fingerprint_hash != device_hash or not activation.expires_at or activation.expires_at > timezone.now():
                        messages.error(request, 'This renewal request is no longer valid. Start again from the software page.')
                        return redirect('products:detail', slug=activation.purchase.product.slug)
                    activation.expires_at = timezone.now() + timedelta(days=365)
                    activation.pending_device_fingerprint_hash = ''
                activation.save(update_fields=['device_fingerprint_hash', 'pending_device_fingerprint_hash', 'activated_at', 'expires_at', 'updated_at'])
                otp.is_used = True
                otp.save(update_fields=['is_used'])
            for key in ('license_activation_id', 'license_otp_id', 'license_device_hash', 'license_otp_purpose'):
                request.session.pop(key, None)
            messages.success(request, 'Device authorization confirmed. Your license is valid for one year.')
            return redirect('products:detail', slug=activation.purchase.product.slug)
    return render(request, 'products/device_otp.html', {'email': request.user.email, 'product': activation.purchase.product})


def _license_api_payload(request):
    if request.content_type == 'application/json':
        try:
            payload = json.loads(request.body or b'{}')
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None
        return payload if isinstance(payload, dict) else None
    return request.POST


@csrf_exempt
@require_POST
def api_activate_license(request):
    from .models import LicenseActivation
    payload = _license_api_payload(request)
    if payload is None:
        return JsonResponse({'status': 'error', 'message': 'Send a valid JSON body.'}, status=400)
    license_key = str(payload.get('license_key', '')).strip()
    device_hash = _device_fingerprint_hash(payload.get('device_id'))
    if not license_key or not device_hash:
        return JsonResponse({'status': 'error', 'message': 'license_key and a stable device_id are required.'}, status=400)
    purchase = SoftProductPurchase.objects.select_related('buyer', 'product').filter(
        license_key_hash=hashlib.sha256(license_key.encode('utf-8')).hexdigest(), is_paid=True
    ).first()
    if not purchase:
        return JsonResponse({'status': 'invalid_license'}, status=404)
    activation, _ = LicenseActivation.objects.get_or_create(purchase=purchase)
    if activation.is_active:
        if activation.device_fingerprint_hash == device_hash:
            return JsonResponse({'status': 'active', 'expires_at': activation.expires_at.isoformat()})

    purpose = 'device_renewal' if activation.device_fingerprint_hash == device_hash else 'device_activation'
    supplied_code = str(payload.get('otp', '')).strip()
    if not supplied_code:
        otp, error = _send_license_otp(purchase.buyer, activation, purpose)
        if error:
            code = 429 if 'one minute' in error else 503
            return JsonResponse({'status': 'error', 'message': error}, status=code)
        activation.pending_device_fingerprint_hash = device_hash
        activation.save(update_fields=['pending_device_fingerprint_hash', 'updated_at'])
        return JsonResponse({'status': 'otp_sent', 'purpose': purpose, 'expires_in_seconds': 300})

    otp = OTP.objects.filter(activation=activation, purpose=purpose, is_used=False).order_by('-created_at').first()
    if not otp or otp.expires_at <= timezone.now() or otp.attempts >= OTP.MAX_ATTEMPTS:
        return JsonResponse({'status': 'otp_expired', 'message': 'Request a new activation code.'}, status=400)
    if not re.fullmatch(r'\d{6}', supplied_code) or not check_password(supplied_code, otp.code):
        otp.attempts += 1
        otp.save(update_fields=['attempts'])
        return JsonResponse({'status': 'invalid_otp'}, status=400)

    with transaction.atomic():
        activation = LicenseActivation.objects.select_for_update().get(pk=activation.pk)
        if activation.pending_device_fingerprint_hash != device_hash:
            return JsonResponse({'status': 'activation_request_changed'}, status=409)
        if purpose == 'device_renewal':
            if activation.device_fingerprint_hash != device_hash or not activation.expires_at or activation.expires_at > timezone.now():
                return JsonResponse({'status': 'renewal_not_due'}, status=409)
        activation.device_fingerprint_hash = device_hash
        activation.pending_device_fingerprint_hash = ''
        activation.activated_at = activation.activated_at or timezone.now()
        activation.expires_at = timezone.now() + timedelta(days=365)
        activation.save(update_fields=['device_fingerprint_hash', 'pending_device_fingerprint_hash', 'activated_at', 'expires_at', 'updated_at'])
        otp.is_used = True
        otp.save(update_fields=['is_used'])
    return JsonResponse({'status': 'active', 'expires_at': activation.expires_at.isoformat()})


@csrf_exempt
@require_POST
def api_validate_license(request):
    from .models import LicenseActivation
    payload = _license_api_payload(request)
    if payload is None:
        return JsonResponse({'status': 'error', 'message': 'Send a valid JSON body.'}, status=400)
    device_hash = _device_fingerprint_hash(payload.get('device_id'))
    license_key = str(payload.get('license_key', '')).strip()
    purchase = SoftProductPurchase.objects.filter(
        license_key_hash=hashlib.sha256(license_key.encode('utf-8')).hexdigest(), is_paid=True
    ).first()
    if not purchase or not device_hash:
        return JsonResponse({'status': 'invalid_license'}, status=403)
    activation = LicenseActivation.objects.filter(purchase=purchase).first()
    if not activation or not activation.is_active or activation.device_fingerprint_hash != device_hash:
        return JsonResponse({'status': 'inactive_or_wrong_device'}, status=403)
    return JsonResponse({'status': 'valid', 'expires_at': activation.expires_at.isoformat()})


@login_required
@require_POST
def confirm_payment(request, slug):
    product = get_object_or_404(SoftProduct, slug=slug, status='published')
    purchase, _ = SoftProductPurchase.objects.get_or_create(
        buyer=request.user,
        product=product,
        defaults={'amount_paid': product.price, 'is_paid': False},
    )
    if purchase.is_paid:
        return redirect('products:download', slug=product.slug)
    if not settings.SSLCOMMERZ_STORE_ID or not settings.SSLCOMMERZ_STORE_PASSWORD:
        messages.error(request, 'Online payment is not configured yet. Please contact the administrator.')
        return redirect('products:detail', slug=product.slug)
    from payments.services import GatewayError, start_sslcommerz_payment
    tran_id = 'SMP' + uuid.uuid4().hex[:24]
    purchase.payment_session_id = tran_id
    purchase.save(update_fields=['payment_session_id'])
    purchase = assess_soft_purchase_risk(purchase)
    if purchase.risk_level == 'high':
        messages.error(request, 'This purchase was held for a security review. Please contact support before retrying.')
        return redirect('products:detail', slug=product.slug)
    try:
        gateway_url = start_sslcommerz_payment(
            tran_id=tran_id, amount=purchase.amount_paid, customer=request.user,
            product_name=product.title,
            success_url=request.build_absolute_uri(reverse('payments:callback')),
            fail_url=request.build_absolute_uri(reverse('payments:callback')),
            cancel_url=request.build_absolute_uri(reverse('payments:callback')),
            ipn_url=request.build_absolute_uri(reverse('payments:ipn')),
        )
    except ValueError as error:
        messages.error(request, str(error))
        return redirect('products:detail', slug=product.slug)
    except (GatewayError, RuntimeError):
        messages.error(request, 'Could not start payment. Please try again.')
        return redirect('products:detail', slug=product.slug)
    return redirect(gateway_url)


# ---------- download ----------

@login_required
def download_product(request, slug):
    from .models import LicenseActivation
    product = get_object_or_404(SoftProduct, slug=slug)
    purchase = SoftProductPurchase.objects.filter(buyer=request.user, product=product, is_paid=True).first()
    if not purchase:
        messages.error(request, 'You need to purchase this product before downloading.')
        return redirect('products:detail', slug=slug)
    activation = LicenseActivation.objects.filter(purchase=purchase).first()
    raw_device_id = request.POST.get('device_id', '').strip()
    try:
        device_id = str(uuid.UUID(raw_device_id))
    except (ValueError, AttributeError):
        device_id = ''
    submitted_hash = hashlib.sha256(device_id.encode('utf-8')).hexdigest() if device_id else ''
    if not activation or not activation.is_active or submitted_hash != activation.device_fingerprint_hash:
        messages.error(request, 'Authorize this device with the email OTP before downloading.')
        return redirect('products:detail', slug=slug)
    if not product.file:
        raise Http404('File not available.')
    file_path = product.file.path
    if not os.path.exists(file_path):
        raise Http404('File not found on server.')
    mime_type, _ = mimetypes.guess_type(file_path)
    mime_type = mime_type or 'application/octet-stream'
    filename = os.path.basename(file_path)
    response = FileResponse(product.file.open('rb'), content_type=mime_type)
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


# ---------- review ----------

@login_required
@require_POST
def submit_review(request, slug):
    product = get_object_or_404(SoftProduct, slug=slug, status='published')
    if not SoftProductPurchase.objects.filter(buyer=request.user, product=product, is_paid=True).exists():
        messages.error(request, 'Only buyers can review this product.')
        return redirect('products:detail', slug=slug)
    try:
        rating = int(request.POST.get('rating', 5))
    except (TypeError, ValueError):
        messages.error(request, 'Please choose a rating from 1 to 5.')
        return redirect('products:detail', slug=slug)
    if rating < 1 or rating > 5:
        messages.error(request, 'Please choose a rating from 1 to 5.')
        return redirect('products:detail', slug=slug)
    comment = request.POST.get('comment', '').strip()
    SoftProductReview.objects.update_or_create(
        product=product, user=request.user,
        defaults={'rating': rating, 'comment': comment},
    )
    summary = product.reviews.aggregate(avg=Avg('rating'), total=Count('id'))
    SoftProduct.objects.filter(pk=product.pk).update(
        rating=summary['avg'] or 0,
        rating_count=summary['total'],
    )
    messages.success(request, 'Your review has been saved.')
    return redirect('products:detail', slug=slug)


# ---------- seller views ----------

@seller_required
def seller_product_list(request):
    products = SoftProduct.objects.filter(seller=request.user)
    return render(request, 'products/seller_products.html', {'products': products})


@seller_required
def seller_product_create(request):
    form = SoftProductForm(request.POST or None, request.FILES or None)
    formset = SoftProductFeatureFormSet(request.POST or None, prefix='features')
    if request.method == 'POST' and form.is_valid() and formset.is_valid():
        product = form.save(commit=False)
        product.seller = request.user
        product.save()
        formset.instance = product
        formset.save()
        messages.success(request, 'Product created successfully.')
        return redirect('products:seller_products')
    return render(request, 'products/seller_product_form.html', {
        'form': form, 'formset': formset, 'heading': 'Add New Product',
    })


@seller_required
def seller_product_edit(request, pk):
    product = get_object_or_404(SoftProduct, pk=pk, seller=request.user)
    form = SoftProductForm(request.POST or None, request.FILES or None, instance=product)
    formset = SoftProductFeatureFormSet(request.POST or None, instance=product, prefix='features')
    if request.method == 'POST' and form.is_valid() and formset.is_valid():
        form.save()
        formset.save()
        messages.success(request, 'Product updated successfully.')
        return redirect('products:seller_products')
    return render(request, 'products/seller_product_form.html', {
        'form': form, 'formset': formset, 'heading': 'Edit Product',
    })


@seller_required
@require_POST
def seller_product_delete(request, pk):
    product = get_object_or_404(SoftProduct, pk=pk, seller=request.user)
    product.delete()
    messages.success(request, 'Product deleted.')
    return redirect('products:seller_products')
