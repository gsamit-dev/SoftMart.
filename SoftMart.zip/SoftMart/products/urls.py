from django.urls import path
from . import views

app_name = 'products'

urlpatterns = [
    # public
    path('soft-products/', views.product_list, name='list'),
    path('soft-products/<slug:slug>/', views.product_detail, name='detail'),
    path('soft-products/<slug:slug>/buy/', views.buy_product, name='buy'),
    path('soft-products/<slug:slug>/authorize-device/', views.activate_device, name='activate_device'),
    path('license/verify-otp/', views.verify_device_otp, name='verify_device_otp'),
    path('api/licenses/activate/', views.api_activate_license, name='api_activate_license'),
    path('api/licenses/validate/', views.api_validate_license, name='api_validate_license'),
    path('soft-products/<slug:slug>/pay/', views.confirm_payment, name='pay'),
    path('soft-products/<slug:slug>/download/', views.download_product, name='download'),
    path('soft-products/<slug:slug>/review/', views.submit_review, name='review'),

    # seller
    path('seller/soft-products/', views.seller_product_list, name='seller_products'),
    path('seller/soft-products/add/', views.seller_product_create, name='seller_add'),
    path('seller/soft-products/<int:pk>/edit/', views.seller_product_edit, name='seller_edit'),
    path('seller/soft-products/<int:pk>/delete/', views.seller_product_delete, name='seller_delete'),
]
