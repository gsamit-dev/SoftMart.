from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('products', '0003_softproduct_rating_softproduct_rating_count_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='softproductpurchase',
            name='payment_session_id',
            field=models.CharField(blank=True, max_length=255),
        ),
    ]
