from datetime import timedelta

from django.contrib import messages
from django.contrib.auth.hashers import check_password, make_password
from django.contrib.auth.decorators import login_required
from django.core.mail import EmailMultiAlternatives
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from accounts.models import User
from .models import OTP


def _send_otp_email(user, code):
    name = user.full_name or user.email
    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/></head>
<body style="margin:0;padding:0;background:#0d1a31;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0d1a31;padding:40px 0;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#111b2e;border-radius:20px;border:1px solid rgba(125,146,255,0.25);overflow:hidden;max-width:560px;width:100%;">
        <tr>
          <td style="background:linear-gradient(135deg,#5e7bff,#845dff);padding:36px 40px;text-align:center;">
            <h1 style="margin:0;color:#fff;font-size:2rem;letter-spacing:1px;">SoftMart</h1>
            <p style="margin:8px 0 0;color:rgba(255,255,255,0.85);font-size:0.95rem;">Premium Digital Software Marketplace</p>
          </td>
        </tr>
        <tr>
          <td style="padding:40px;">
            <h2 style="margin:0 0 8px;color:#ecf2ff;font-size:1.4rem;">Welcome to SoftMart! 🎉</h2>
            <p style="margin:0 0 24px;color:#c0ccf2;font-size:0.95rem;line-height:1.6;">
              Hi <strong style="color:#ecf2ff;">{name}</strong>, your account has been created successfully.<br/>
              Use the OTP below to verify your email. Valid for <strong style="color:#7cc7ff;">5 minutes</strong>.
            </p>
            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:28px;">
              <tr><td align="center">
                <div style="display:inline-block;background:linear-gradient(135deg,rgba(94,123,255,0.15),rgba(132,93,255,0.15));border:2px solid rgba(125,146,255,0.45);border-radius:16px;padding:28px 48px;">
                  <p style="margin:0 0 10px;color:#a8badc;font-size:0.78rem;letter-spacing:3px;text-transform:uppercase;">One-Time Password</p>
                  <p style="margin:0;font-size:3rem;font-weight:bold;letter-spacing:14px;color:#ffffff;font-family:'Courier New',monospace;">{code}</p>
                </div>
              </td></tr>
            </table>
            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
              <tr>
                <td style="background:rgba(255,97,97,0.08);border:1px solid rgba(255,97,97,0.2);border-radius:10px;padding:14px 18px;">
                  <p style="margin:0;color:#ff9d9d;font-size:0.85rem;">🔒 <strong>Do not share this OTP</strong> with anyone. SoftMart will never ask for your OTP.</p>
                </td>
              </tr>
            </table>
            <p style="margin:0;color:#8396bf;font-size:0.85rem;line-height:1.6;">If you did not create this account, you can safely ignore this email.</p>
          </td>
        </tr>
        <tr>
          <td style="background:rgba(0,0,0,0.2);padding:20px 40px;text-align:center;border-top:1px solid rgba(125,146,255,0.1);">
            <p style="margin:0;color:#4a5a80;font-size:0.8rem;">© 2026 SoftMart. All rights reserved.</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""
    plain = f"Hello {name},\n\nWelcome to SoftMart!\n\nYour OTP is: {code}\n\nValid for 5 minutes. Do not share it.\n\nSoftMart Team"
    msg = EmailMultiAlternatives(
        subject='Welcome to SoftMart - Verify Your Account',
        body=plain,
        from_email=None,
        to=[user.email],
    )
    msg.attach_alternative(html, 'text/html')
    msg.send(fail_silently=False)


def otp_verify_view(request):
    # get user_id from session (set during registration)
    user_id = request.session.get('otp_user_id')
    if not user_id:
        return redirect('accounts:register')

    user = get_object_or_404(User, id=user_id)

    if request.method == 'POST':
        code = ''.join(request.POST.get(f'd{i}', '') for i in range(1, 7))
        otp = OTP.objects.filter(user=user, purpose='email', is_used=False).order_by('-created_at').first()

        if not otp:
            messages.error(request, 'No OTP found. Please request a new one.')
        elif otp.expires_at <= timezone.now():
            messages.error(request, 'Your OTP has expired. Please request a new OTP.')
        elif otp.attempts >= OTP.MAX_ATTEMPTS:
            messages.error(request, 'Too many attempts. Please request a new OTP.')
        elif not check_password(code, otp.code):
            otp.attempts += 1
            otp.save(update_fields=['attempts'])
            messages.error(request, 'Invalid OTP. Please try again.')
        else:
            otp.is_used = True
            otp.save(update_fields=['is_used'])
            user.is_email_verified = True
            user.save(update_fields=['is_email_verified'])
            del request.session['otp_user_id']
            messages.success(request, 'Your account has been verified successfully. Please login to continue.')
            return redirect('accounts:login')

    otp = OTP.objects.filter(user=user, purpose='email', is_used=False).order_by('-created_at').first()
    expires_at_iso = otp.expires_at.isoformat() if otp else None
    return render(request, 'otp/verify.html', {'email': user.email, 'expires_at': expires_at_iso})


def resend_otp_view(request):
    user_id = request.session.get('otp_user_id')
    if not user_id:
        return redirect('accounts:register')

    user = get_object_or_404(User, id=user_id)

    if OTP.objects.filter(user=user, purpose='email', created_at__gte=timezone.now() - timedelta(minutes=1)).exists():
        messages.info(request, 'Please wait one minute before requesting another code.')
        return redirect('otp:verify')

    OTP.objects.filter(user=user, purpose='email', is_used=False).update(is_used=True)
    code = OTP.generate_code()
    _send_otp_email(user, code)
    OTP.objects.create(
        user=user,
        purpose='email',
        code=make_password(code),
        expires_at=timezone.now() + timedelta(minutes=5),
    )
    messages.success(request, 'A new OTP has been sent to your email.')
    return redirect('otp:verify')


# kept for backward compat (dashboard resend button)
@login_required
def request_otp(request):
    return resend_otp_view(request)
