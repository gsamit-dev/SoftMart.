from django.urls import path
from . import views

app_name = 'otp'

urlpatterns = [
    path('otp/verify/', views.otp_verify_view, name='verify'),
    path('otp/resend/', views.resend_otp_view, name='resend'),
    path('otp/request/', views.request_otp, name='request'),
]
