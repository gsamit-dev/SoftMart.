import secrets

from django.conf import settings
from django.db import models


class OTP(models.Model):
    MAX_ATTEMPTS = 5
    PURPOSE_CHOICES = [
        ('email', 'Email'), ('password_reset', 'Password Reset'), ('phone', 'Phone'),
        ('device_activation', 'Device Activation'), ('device_renewal', 'Device Renewal'),
    ]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='otp_codes')
    activation = models.ForeignKey('products.LicenseActivation', on_delete=models.SET_NULL, null=True, blank=True, related_name='otp_codes')
    purpose = models.CharField(max_length=30, choices=PURPOSE_CHOICES, default='email')
    code = models.CharField(max_length=128)
    expires_at = models.DateTimeField()
    attempts = models.PositiveIntegerField(default=0)
    is_used = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    @staticmethod
    def generate_code():
        return f'{secrets.randbelow(900000) + 100000:06d}'

    def __str__(self):
        return f'{self.user.email} - {self.purpose}'
