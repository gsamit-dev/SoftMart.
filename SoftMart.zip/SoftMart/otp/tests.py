from django.contrib.auth import get_user_model
from django.core import mail
from django.test import TestCase
from django.urls import reverse

from .models import OTP


class OTPTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            email='verify@example.com', username='verify', password='strong-password-123', phone_number='01800000000'
        )
        self.client.login(email='verify@example.com', password='strong-password-123')

    def test_request_otp_hashes_the_code_and_sends_an_email(self):
        response = self.client.post(reverse('otp:request'))
        self.assertRedirects(response, reverse('otp:verify'))
        otp = OTP.objects.get(user=self.user)
        code = mail.outbox[0].body.split()[4].rstrip('.')
        self.assertNotEqual(otp.code, code)
        self.assertEqual(len(mail.outbox), 1)

        response = self.client.post(reverse('otp:verify'), {
            **{f'd{index}': digit for index, digit in enumerate(code, start=1)},
        })
        self.assertRedirects(response, reverse('dashboard:home'))
        self.user.refresh_from_db()
        self.assertTrue(self.user.is_email_verified)
