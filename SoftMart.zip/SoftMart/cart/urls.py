from django.urls import path

from .views import add_to_cart, buy_now, cart_view, remove_from_cart

app_name = 'cart'

urlpatterns = [
    path('cart/', cart_view, name='cart'),
    path('cart/add/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('cart/buy-now/<int:product_id>/', buy_now, name='buy_now'),
    path('cart/remove/<int:product_id>/', remove_from_cart, name='remove_from_cart'),
]
