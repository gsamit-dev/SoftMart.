from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from catalog.models import Product
from .models import Cart, CartItem


def _get_or_create_cart(user):
    cart, _ = Cart.objects.get_or_create(user=user)
    return cart


@login_required
def cart_view(request):
    cart = _get_or_create_cart(request.user)
    return render(request, 'cart/cart.html', {'cart': cart})


@login_required
@require_POST
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id, status='published')
    if product.stock < 1:
        messages.error(request, 'This product is out of stock.')
        return redirect('catalog:product_detail', slug=product.slug)
    cart = _get_or_create_cart(request.user)
    item, created = CartItem.objects.get_or_create(cart=cart, product=product)
    if not created and item.quantity < product.stock:
        item.quantity += 1
        item.save(update_fields=['quantity'])
    elif created:
        item.save()
    else:
        messages.warning(request, 'You cannot add more than the available stock.')
        return redirect('catalog:product_detail', slug=product.slug)
    messages.success(request, 'Product added to cart.')
    return redirect('catalog:product_detail', slug=product.slug)


@login_required
@require_POST
def buy_now(request, product_id):
    product = get_object_or_404(Product, id=product_id, status='published')
    if product.stock < 1:
        messages.error(request, 'This product is out of stock.')
        return redirect('catalog:product_detail', slug=product.slug)
    cart = _get_or_create_cart(request.user)
    CartItem.objects.update_or_create(cart=cart, product=product, defaults={'quantity': 1})
    return redirect('orders:checkout')


@login_required
@require_POST
def remove_from_cart(request, product_id):
    cart = _get_or_create_cart(request.user)
    CartItem.objects.filter(cart=cart, product_id=product_id).delete()
    messages.info(request, 'Item removed from cart.')
    return redirect('cart:cart')
