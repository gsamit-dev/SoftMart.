from django.urls import path

from .views import payment_callback, payment_checkout_view, payment_history_view, payment_ipn

app_name = 'payments'

urlpatterns = [
    path('checkout/<int:order_id>/', payment_checkout_view, name='checkout'),
    path('payments/', payment_history_view, name='history'),
    path('payments/sslcommerz/callback/', payment_callback, name='callback'),
    path('payments/sslcommerz/ipn/', payment_ipn, name='ipn'),
]
