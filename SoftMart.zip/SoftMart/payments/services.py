from decimal import Decimal, InvalidOperation
import json
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen

from django.conf import settings
from django.db import transaction

from catalog.models import License
from orders.models import Order
from products.models import SoftProductPurchase
from .models import Payment


class GatewayError(Exception):
    pass


def _request_json(url, *, method='GET', data=None):
    body = urlencode(data).encode('utf-8') if data is not None else None
    if method == 'GET' and data:
        url = f'{url}?{urlencode(data)}'
    request = Request(url, data=body, method=method)
    try:
        with urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode('utf-8'))
            if not isinstance(payload, dict):
                raise GatewayError('SSLCommerz returned an invalid response.')
            return payload
    except (HTTPError, URLError, TimeoutError, json.JSONDecodeError, UnicodeDecodeError) as error:
        raise GatewayError('SSLCommerz request failed.') from error


def sslcommerz_base_url():
    return 'https://sandbox.sslcommerz.com' if settings.SSLCOMMERZ_SANDBOX else 'https://securepay.sslcommerz.com'


def sslcommerz_initiation_url():
    host = 'https://sandbox-gw.sslcommerz.com' if settings.SSLCOMMERZ_SANDBOX else 'https://securepay.sslcommerz.com'
    return f'{host}/gwprocess/v4/api.php'


def start_sslcommerz_payment(*, tran_id, amount, customer, product_name, success_url, fail_url, cancel_url, ipn_url):
    if not settings.SSLCOMMERZ_STORE_ID or not settings.SSLCOMMERZ_STORE_PASSWORD:
        raise RuntimeError('SSLCommerz credentials are not configured.')
    amount = Decimal(amount).quantize(Decimal('0.01'))
    if amount < Decimal('10.00') or amount > Decimal('500000.00'):
        raise ValueError('SSLCommerz accepts payment amounts from BDT 10.00 to BDT 500,000.00.')
    profile = getattr(customer, 'profile', None)
    data = {
        'store_id': settings.SSLCOMMERZ_STORE_ID,
        'store_passwd': settings.SSLCOMMERZ_STORE_PASSWORD,
        'total_amount': str(amount),
        'currency': 'BDT',
        'tran_id': tran_id,
        'success_url': success_url,
        'fail_url': fail_url,
        'cancel_url': cancel_url,
        'ipn_url': ipn_url,
        'cus_name': (customer.full_name or customer.email)[:50],
        'cus_email': customer.email[:50],
        'cus_add1': ((profile.address if profile else '') or 'Dhaka')[:50],
        'cus_city': ((profile.city if profile else '') or 'Dhaka')[:50],
        'cus_postcode': ((profile.postal_code if profile else '') or '1000')[:30],
        'cus_country': ((profile.country if profile else '') or 'Bangladesh')[:50],
        'cus_phone': (customer.phone_number or '')[:20],
        'shipping_method': 'NO',
        'num_of_item': '1',
        'product_name': product_name[:255],
        'product_category': 'Software',
        'product_profile': 'non-physical-goods',
    }
    result = _request_json(sslcommerz_initiation_url(), method='POST', data=data)
    gateway_url = result.get('GatewayPageURL')
    if result.get('status') != 'SUCCESS' or not gateway_url:
        raise RuntimeError('SSLCommerz did not return a payment page.')
    parsed_gateway_url = urlparse(gateway_url)
    if parsed_gateway_url.scheme != 'https' or not parsed_gateway_url.hostname or not parsed_gateway_url.hostname.endswith('.sslcommerz.com'):
        raise RuntimeError('SSLCommerz returned an invalid payment page URL.')
    return gateway_url


def validate_sslcommerz_transaction(val_id):
    if not settings.SSLCOMMERZ_STORE_ID or not settings.SSLCOMMERZ_STORE_PASSWORD:
        raise RuntimeError('SSLCommerz credentials are not configured.')
    return _request_json(
        f'{sslcommerz_base_url()}/validator/api/validationserverAPI.php',
        data={
            'val_id': val_id,
            'store_id': settings.SSLCOMMERZ_STORE_ID,
            'store_passwd': settings.SSLCOMMERZ_STORE_PASSWORD,
            'format': 'json',
        },
    )


def fulfill_validated_transaction(tran_id, result):
    if result.get('status') not in {'VALID', 'VALIDATED'} or result.get('tran_id') != tran_id:
        return False
    if result.get('currency', '').upper() != 'BDT':
        return False
    try:
        metadata_payment = Decimal(str(result.get('amount')))
    except (InvalidOperation, TypeError, ValueError):
        return False

    with transaction.atomic():
        payment = Payment.objects.select_for_update().filter(
            gateway_reference=tran_id, provider='sslcommerz'
        ).select_related('order', 'user').first()
        if payment:
            order = Order.objects.select_for_update().get(pk=payment.order_id)
            if metadata_payment != order.total_amount or payment.amount != order.total_amount:
                return False
            if order.status == 'paid' and payment.status == 'paid':
                return True
            if order.status != 'pending' or payment.status != 'pending':
                return False
            reserved = License.objects.select_for_update().filter(order=order, status='reserved')
            if reserved.count() != sum(item.quantity for item in order.items.all()):
                return False
            payment.status = 'paid'
            payment.save(update_fields=['status'])
            order.status = 'paid'
            order.save(update_fields=['status', 'updated_at'])
            reserved.update(owner=order.user, status='assigned')
            return True

        purchase = SoftProductPurchase.objects.select_for_update().filter(payment_session_id=tran_id).first()
        if not purchase or metadata_payment != purchase.amount_paid:
            return False
        if purchase.is_paid:
            return True
        purchase.is_paid = True
        purchase.save(update_fields=['is_paid'])
        purchase.generate_license_key()
        return True
