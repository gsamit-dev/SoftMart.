import uuid

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from orders.models import Order
from products.models import SoftProductPurchase
from .models import Payment
from .services import GatewayError, fulfill_validated_transaction, start_sslcommerz_payment, validate_sslcommerz_transaction


@login_required
def payment_checkout_view(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    payment = get_object_or_404(Payment, order=order, user=request.user)
    if request.method == 'POST':
        if payment.status == 'paid' or order.status == 'paid':
            messages.info(request, 'This order has already been paid.')
            return redirect('dashboard:home')
        if order.status != 'pending' or payment.status != 'pending':
            messages.error(request, 'This payment is no longer available.')
            return redirect('orders:history')
        tran_id = 'SMO' + uuid.uuid4().hex[:24]
        payment.provider = 'sslcommerz'
        payment.gateway_reference = tran_id
        payment.save(update_fields=['provider', 'gateway_reference'])
        try:
            gateway_url = start_sslcommerz_payment(
                tran_id=tran_id, amount=order.total_amount, customer=request.user,
                product_name=', '.join(item.product.title for item in order.items.select_related('product')),
                success_url=request.build_absolute_uri(reverse('payments:callback')),
                fail_url=request.build_absolute_uri(reverse('payments:callback')),
                cancel_url=request.build_absolute_uri(reverse('payments:callback')),
                ipn_url=request.build_absolute_uri(reverse('payments:ipn')),
            )
        except ValueError as error:
            messages.error(request, str(error))
            return redirect('payments:checkout', order_id=order.id)
        except (GatewayError, RuntimeError):
            messages.error(request, 'Could not connect to SSLCommerz. Please try again or contact the administrator.')
            return redirect('payments:checkout', order_id=order.id)
        return redirect(gateway_url)
    return render(request, 'payments/checkout.html', {'order': order, 'payment': payment})


@login_required
def payment_history_view(request):
    payments = Payment.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'payments/history.html', {'payments': payments})


@csrf_exempt
@require_POST
def payment_callback(request):
    tran_id = request.POST.get('tran_id', '').strip()
    val_id = request.POST.get('val_id', '').strip()
    if not tran_id:
        return HttpResponseBadRequest('Missing transaction id')
    if val_id:
        try:
            result = validate_sslcommerz_transaction(val_id)
        except (GatewayError, ValueError, RuntimeError):
            return HttpResponse('Payment validation is temporarily unavailable.', status=503)
        if fulfill_validated_transaction(tran_id, result):
            if request.user.is_authenticated:
                messages.success(request, 'Payment verified. Your purchase is ready.')
                return redirect('dashboard:home')
            return redirect('accounts:login')
    if request.user.is_authenticated:
        messages.warning(request, 'Payment was not confirmed. You can retry it from your orders.')
        return redirect('orders:history')
    return redirect('accounts:login')


@csrf_exempt
@require_POST
def payment_ipn(request):
    tran_id = request.POST.get('tran_id', '').strip()
    val_id = request.POST.get('val_id', '').strip()
    if not tran_id or not val_id:
        return HttpResponseBadRequest('Missing transaction details')
    try:
        result = validate_sslcommerz_transaction(val_id)
    except (GatewayError, ValueError, RuntimeError):
        return HttpResponse(status=503)
    if not fulfill_validated_transaction(tran_id, result):
        return HttpResponse(status=400)
    return HttpResponse(status=200)
