from django.contrib import admin

from .models import Payment


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('id', 'order', 'user', 'amount', 'provider', 'status', 'created_at')
    list_filter = ('provider', 'status')
    search_fields = ('gateway_reference', 'user__email')
    readonly_fields = ('created_at',)
