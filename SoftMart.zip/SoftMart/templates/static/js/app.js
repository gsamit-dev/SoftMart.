document.addEventListener('DOMContentLoaded', function () {

  // ── Theme toggle ──
  const toggle = document.getElementById('theme-toggle');
  const saved = localStorage.getItem('theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
  if (toggle) toggle.textContent = saved === 'light' ? '☀️ Light' : '🌙 Dark';

  if (toggle) {
    toggle.addEventListener('click', function () {
      const current = document.documentElement.getAttribute('data-theme');
      const next = current === 'light' ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('theme', next);
      toggle.textContent = next === 'light' ? '☀️ Light' : '🌙 Dark';
    });
  }

  // ── OTP inputs ──
  const otpInputs = document.querySelectorAll('.otp-inputs input');
  if (otpInputs.length) {
    otpInputs.forEach((input, index) => {
      input.addEventListener('input', function () {
        if (this.value.length > 1) this.value = this.value.slice(0, 1);
        if (this.value && index < otpInputs.length - 1) otpInputs[index + 1].focus();
      });
      input.addEventListener('keydown', function (event) {
        if (event.key === 'Backspace' && !this.value && index > 0) otpInputs[index - 1].focus();
      });
    });
  }

});
