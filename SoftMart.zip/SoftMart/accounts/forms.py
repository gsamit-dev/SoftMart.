from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.utils.text import slugify

User = get_user_model()


class RegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    full_name = forms.CharField(max_length=120, required=True)
    phone_number = forms.CharField(max_length=20, required=True)
    role = forms.ChoiceField(
        choices=[
            (User.ROLE_CUSTOMER, 'Customer'),
            (User.ROLE_SELLER, 'Seller'),
        ],
        initial=User.ROLE_CUSTOMER,
        required=True,
        label='Account type',
    )

    class Meta:
        model = User
        fields = ('full_name', 'email', 'phone_number', 'role', 'password1', 'password2')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Keep Django's password validation, but do not render its default
        # help-text list on the registration page.
        self.fields['password1'].help_text = ''
        self.fields['password2'].help_text = ''

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError('A user with this email already exists.')
        return email

    def clean_phone_number(self):
        phone = self.cleaned_data.get('phone_number')
        if User.objects.filter(phone_number=phone).exists():
            raise forms.ValidationError('A user with this phone number already exists.')
        return phone

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.full_name = self.cleaned_data['full_name']
        user.phone_number = self.cleaned_data['phone_number']
        user.role = self.cleaned_data['role']
        # Email is the login identifier, but AbstractUser still requires a
        # unique username.  This also avoids clashes between similar emails.
        base_username = slugify(self.cleaned_data['email'].split('@')[0]) or 'user'
        base_username = base_username[:140]
        username = base_username
        suffix = 1
        while User.objects.filter(username=username).exists():
            suffix += 1
            username = f'{base_username[:150 - len(str(suffix)) - 1]}-{suffix}'
        user.username = username
        if commit:
            user.save()
        return user
