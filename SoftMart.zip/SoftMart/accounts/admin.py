from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User, UserProfile


@admin.register(User)
class SoftMartUserAdmin(UserAdmin):
    list_display = ('email', 'full_name', 'role', 'account_status', 'is_email_verified', 'is_staff')
    list_filter = ('role', 'account_status', 'is_email_verified', 'is_staff')
    search_fields = ('email', 'username', 'full_name', 'phone_number')
    fieldsets = UserAdmin.fieldsets + (
        ('SoftMart profile', {'fields': ('full_name', 'phone_number', 'avatar', 'role', 'account_status', 'is_email_verified', 'is_phone_verified')}),
    )


admin.site.register(UserProfile)
