from datetime import timedelta

from django.contrib import messages
from django.core.cache import cache
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import check_password, make_password
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import RegistrationForm
from .models import User
from otp.models import OTP
from otp.views import _send_otp_email


def register_view(request):
    if request.user.is_authenticated:
        return redirect('catalog:home')
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            request.session['otp_user_id'] = user.id
            code = OTP.generate_code()
            _send_otp_email(user, code)
            OTP.objects.create(
                user=user,
                purpose='email',
                code=make_password(code),
                expires_at=timezone.now() + timedelta(minutes=5),
            )
            return redirect('otp:verify')
    else:
        form = RegistrationForm()
    return render(request, 'accounts/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('catalog:home')
    next_url = request.POST.get('next') or request.GET.get('next') or ''
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        ip = request.META.get('REMOTE_ADDR', 'unknown')
        email_key = f'login-fail-email:{(email or "").strip().lower()}'
        ip_key = f'login-fail-ip:{ip}'
        if max(cache.get(email_key, 0), cache.get(ip_key, 0)) >= 10:
            messages.error(request, 'Too many sign-in attempts. Try again in 15 minutes.')
            return render(request, 'accounts/login.html', {'next': next_url}, status=429)
        user = authenticate(request, username=email, password=password)
        if user is None or user.account_status != 'active':
            for throttle_key in (email_key, ip_key):
                cache.set(throttle_key, cache.get(throttle_key, 0) + 1, timeout=900)
            messages.error(request, 'Invalid email or password, or account is not active.')
        elif not user.is_email_verified:
            request.session['otp_user_id'] = user.id
            messages.warning(request, 'Please verify your email first.')
            return redirect('otp:verify')
        else:
            cache.delete(email_key)
            cache.delete(ip_key)
            login(request, user)
            if next_url and next_url.startswith('/'):
                return redirect(next_url)
            return redirect('dashboard:home')
    return render(request, 'accounts/login.html', {'next': next_url})


@require_POST
def logout_view(request):
    logout(request)
    return redirect('catalog:home')


@login_required
def change_password_view(request):
    if request.method == 'POST':
        current = request.POST.get('current_password')
        new = request.POST.get('new_password')
        if request.user.check_password(current):
            try:
                validate_password(new, request.user)
            except ValidationError as error:
                messages.error(request, ' '.join(error.messages))
                return render(request, 'accounts/change_password.html')
            request.user.set_password(new)
            request.user.save()
            update_session_auth_hash(request, request.user)
            messages.success(request, 'Password changed successfully.')
            return redirect('dashboard:home')
        messages.error(request, 'Current password is incorrect.')
    return render(request, 'accounts/change_password.html')


# ── Forgot Password Step 1: enter email ──
def forgot_password_view(request):
    if request.method == 'POST':
        email = request.POST.get('email', '').strip()
        user = User.objects.filter(email__iexact=email, account_status='active', is_email_verified=True).first()
        if user:
            # rate limit: 1 per minute
            if not OTP.objects.filter(
                user=user, purpose='password_reset',
                created_at__gte=timezone.now() - timedelta(minutes=1)
            ).exists():
                OTP.objects.filter(user=user, purpose='password_reset', is_used=False).update(is_used=True)
                code = OTP.generate_code()
                _send_password_reset_email(user, code)
                OTP.objects.create(
                    user=user,
                    purpose='password_reset',
                    code=make_password(code),
                    expires_at=timezone.now() + timedelta(minutes=5),
                )
            request.session['reset_user_id'] = user.id
        # always show same message (security: don't reveal if email exists)
        messages.success(request, 'If that email exists, a reset code has been sent.')
        return redirect('accounts:forgot_password_verify')
    return render(request, 'accounts/forgot_password.html')


# ── Forgot Password Step 2: verify OTP ──
def forgot_password_verify_view(request):
    user_id = request.session.get('reset_user_id')
    if not user_id:
        return redirect('accounts:forgot_password')
    user = get_object_or_404(User, id=user_id)

    if request.method == 'POST':
        code = ''.join(request.POST.get(f'd{i}', '') for i in range(1, 7))
        otp = OTP.objects.filter(user=user, purpose='password_reset', is_used=False).order_by('-created_at').first()

        if not otp:
            messages.error(request, 'No OTP found. Please request a new one.')
        elif otp.expires_at <= timezone.now():
            messages.error(request, 'OTP has expired. Please request a new one.')
        elif otp.attempts >= OTP.MAX_ATTEMPTS:
            messages.error(request, 'Too many attempts. Please request a new OTP.')
        elif not check_password(code, otp.code):
            otp.attempts += 1
            otp.save(update_fields=['attempts'])
            messages.error(request, 'Invalid OTP. Please try again.')
        else:
            otp.is_used = True
            otp.save(update_fields=['is_used'])
            request.session['reset_verified_user_id'] = user.id
            del request.session['reset_user_id']
            return redirect('accounts:forgot_password_reset')

    otp = OTP.objects.filter(user=user, purpose='password_reset', is_used=False).order_by('-created_at').first()
    expires_at_iso = otp.expires_at.isoformat() if otp else None
    return render(request, 'accounts/forgot_password_verify.html', {
        'email': user.email,
        'expires_at': expires_at_iso,
    })


# ── Forgot Password Step 3: set new password ──
def forgot_password_reset_view(request):
    user_id = request.session.get('reset_verified_user_id')
    if not user_id:
        return redirect('accounts:forgot_password')
    user = get_object_or_404(User, id=user_id)

    if request.method == 'POST':
        new = request.POST.get('new_password', '')
        confirm = request.POST.get('confirm_password', '')
        if new != confirm:
            messages.error(request, 'Passwords do not match.')
        else:
            try:
                validate_password(new, user)
            except ValidationError as e:
                messages.error(request, ' '.join(e.messages))
                return render(request, 'accounts/forgot_password_reset.html')
            user.set_password(new)
            user.save()
            del request.session['reset_verified_user_id']
            login(request, user)
            messages.success(request, 'Password reset successful. You are now logged in.')
            return redirect('dashboard:home')
    return render(request, 'accounts/forgot_password_reset.html')


def _send_password_reset_email(user, code):
    from django.core.mail import EmailMultiAlternatives
    name = user.full_name or user.email
    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/></head>
<body style="margin:0;padding:0;background:#0d1a31;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0d1a31;padding:40px 0;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#111b2e;border-radius:20px;border:1px solid rgba(125,146,255,0.25);overflow:hidden;max-width:560px;width:100%;">
        <tr>
          <td style="background:linear-gradient(135deg,#5e7bff,#845dff);padding:36px 40px;text-align:center;">
            <h1 style="margin:0;color:#fff;font-size:2rem;">SoftMart</h1>
            <p style="margin:8px 0 0;color:rgba(255,255,255,0.85);font-size:.95rem;">Password Reset Request</p>
          </td>
        </tr>
        <tr>
          <td style="padding:40px;">
            <h2 style="margin:0 0 16px;color:#ecf2ff;">Reset Your Password 🔑</h2>
            <p style="margin:0 0 24px;color:#c0ccf2;font-size:.95rem;line-height:1.6;">
              Hi <strong style="color:#ecf2ff;">{name}</strong>, use the OTP below to reset your password. Valid for <strong style="color:#7cc7ff;">5 minutes</strong>.
            </p>
            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:28px;">
              <tr><td align="center">
                <div style="display:inline-block;background:linear-gradient(135deg,rgba(94,123,255,0.15),rgba(132,93,255,0.15));border:2px solid rgba(125,146,255,0.45);border-radius:16px;padding:28px 48px;">
                  <p style="margin:0 0 10px;color:#a8badc;font-size:.78rem;letter-spacing:3px;text-transform:uppercase;">Reset Code</p>
                  <p style="margin:0;font-size:3rem;font-weight:bold;letter-spacing:14px;color:#fff;font-family:'Courier New',monospace;">{code}</p>
                </div>
              </td></tr>
            </table>
            <table width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td style="background:rgba(255,97,97,0.08);border:1px solid rgba(255,97,97,0.2);border-radius:10px;padding:14px 18px;">
                  <p style="margin:0;color:#ff9d9d;font-size:.85rem;">🔒 If you did not request a password reset, please ignore this email.</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="background:rgba(0,0,0,0.2);padding:20px 40px;text-align:center;border-top:1px solid rgba(125,146,255,0.1);">
            <p style="margin:0;color:#4a5a80;font-size:.8rem;">© 2026 SoftMart. All rights reserved.</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""
    plain = f"Hi {name},\n\nYour SoftMart password reset OTP is: {code}\n\nValid for 5 minutes.\n\nSoftMart Team"
    msg = EmailMultiAlternatives(
        subject='SoftMart - Password Reset Code',
        body=plain,
        from_email=None,
        to=[user.email],
    )
    msg.attach_alternative(html, 'text/html')
    msg.send(fail_silently=False)
