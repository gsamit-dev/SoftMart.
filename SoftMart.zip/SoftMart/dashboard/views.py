from django.contrib.auth.decorators import login_required
from django.db.models import Count, Sum
from django.shortcuts import render

from orders.models import Order
from products.models import SoftProduct, SoftProductPurchase


@login_required
def dashboard_home(request):
    context = {}

    if request.user.role == 'seller':
        products = SoftProduct.objects.filter(seller=request.user)
        sales = SoftProductPurchase.objects.filter(product__seller=request.user, is_paid=True)
        total_revenue = sales.aggregate(total=Sum('amount_paid'))['total'] or 0
        recent_sales = sales.select_related('product', 'buyer').order_by('-created_at')[:10]
        top_products = (
            products.annotate(sale_count=Count('purchases'))
            .order_by('-sale_count')[:5]
        )
        context.update({
            'is_seller': True,
            'total_products': products.count(),
            'total_sales': sales.count(),
            'total_revenue': total_revenue,
            'recent_sales': recent_sales,
            'top_products': top_products,
        })
    else:
        orders = Order.objects.filter(user=request.user).order_by('-created_at')[:5]
        purchases = SoftProductPurchase.objects.filter(buyer=request.user, is_paid=True).select_related('product').order_by('-created_at')[:5]
        context.update({
            'is_seller': False,
            'orders': orders,
            'purchases': purchases,
            'total_orders': Order.objects.filter(user=request.user).count(),
            'total_purchases': SoftProductPurchase.objects.filter(buyer=request.user, is_paid=True).count(),
        })

    return render(request, 'dashboard/dashboard.html', context)
