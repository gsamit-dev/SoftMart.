from django import forms
from django.forms import inlineformset_factory

from catalog.models import Product, ProductFeature


class SellerProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = (
            'title', 'short_description', 'description', 'category', 'brand', 'version',
            'license_type', 'duration_days', 'price', 'discount_price', 'stock',
            'operating_system', 'image', 'file', 'status', 'is_featured',
        )
        widgets = {
            'description': forms.Textarea(attrs={'rows': 5}),
        }

    def clean(self):
        cleaned_data = super().clean()
        price = cleaned_data.get('price')
        discount_price = cleaned_data.get('discount_price')
        if price is not None and discount_price is not None and discount_price > price:
            self.add_error('discount_price', 'Discount price cannot exceed the regular price.')
        return cleaned_data


ProductFeatureFormSet = inlineformset_factory(
    Product,
    ProductFeature,
    fields=('text',),
    extra=3,
    can_delete=True,
    widgets={'text': forms.TextInput(attrs={'placeholder': 'e.g. Lifetime license, Windows 10/11 support'})},
)
