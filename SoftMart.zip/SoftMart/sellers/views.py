from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from catalog.models import Product

from .forms import SellerProductForm


def seller_required(view):
    @wraps(view)
    @login_required
    def wrapped(request, *args, **kwargs):
        if request.user.role != 'seller' and not request.user.is_staff:
            return HttpResponseForbidden('Seller access is required.')
        return view(request, *args, **kwargs)
    return wrapped


@seller_required
def product_list(request):
    products = Product.objects.filter(seller=request.user).select_related('category')
    return render(request, 'sellers/products.html', {'products': products})


@seller_required
def product_create(request):
    form = SellerProductForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        product = form.save(commit=False)
        product.seller = request.user
        product.save()
        messages.success(request, 'Product uploaded successfully.')
        return redirect('sellers:products')
    return render(request, 'sellers/product_form.html', {'form': form, 'heading': 'Upload Product'})


@seller_required
def product_edit(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    form = SellerProductForm(request.POST or None, request.FILES or None, instance=product)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Product updated successfully.')
        return redirect('sellers:products')
    return render(request, 'sellers/product_form.html', {'form': form, 'heading': 'Edit Product'})


@seller_required
@require_POST
def product_archive(request, product_id):
    product = get_object_or_404(Product, id=product_id, seller=request.user)
    product.status = 'archived'
    product.save(update_fields=['status', 'updated_at'])
    messages.info(request, 'Product removed from the store. Order records were kept safely.')
    return redirect('sellers:products')
