from django.urls import path

from . import views

app_name = 'sellers'

urlpatterns = [
    path('seller/products/', views.product_list, name='products'),
    path('seller/products/add/', views.product_create, name='product_add'),
    path('seller/products/<int:product_id>/edit/', views.product_edit, name='product_edit'),
    path('seller/products/<int:product_id>/archive/', views.product_archive, name='product_archive'),
]
