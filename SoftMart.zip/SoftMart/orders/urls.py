from django.urls import path

from .views import cancel_order_view, checkout_view, download_order_item_view, order_history_view

app_name = 'orders'

urlpatterns = [
    path('checkout/', checkout_view, name='checkout'),
    path('orders/', order_history_view, name='history'),
    path('orders/download/<int:order_item_id>/', download_order_item_view, name='download'),
    path('orders/<int:order_id>/cancel/', cancel_order_view, name='cancel'),
]
