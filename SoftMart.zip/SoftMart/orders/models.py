from decimal import Decimal

from django.conf import settings
from django.db import models

from catalog.models import Product


class Order(models.Model):
    STATUS_CHOICES = [('pending', 'Pending'), ('paid', 'Paid'), ('cancelled', 'Cancelled'), ('completed', 'Completed')]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='orders', on_delete=models.CASCADE)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'Order #{self.id}'


class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, related_name='order_items', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    license_type = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return f'{self.product.title} x {self.quantity}'


class Review(models.Model):
    product = models.ForeignKey('catalog.Product', related_name='reviews', on_delete=models.CASCADE)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='reviews', on_delete=models.CASCADE)
    rating = models.PositiveSmallIntegerField(default=5)
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.email} rated {self.product.title}'

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['product', 'user'], name='one_review_per_customer_product'),
            models.CheckConstraint(condition=models.Q(rating__gte=1, rating__lte=5), name='review_rating_between_one_and_five'),
        ]


class FraudAssessment(models.Model):
    RISK_CHOICES = [('low', 'Low'), ('review', 'Review'), ('high', 'High')]
    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name='fraud_assessment')
    score = models.PositiveSmallIntegerField(default=0)
    risk_level = models.CharField(max_length=10, choices=RISK_CHOICES, default='low')
    reasons = models.JSONField(default=list, blank=True)
    reviewed = models.BooleanField(default=False)
    staff_note = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Order #{self.order_id}: {self.risk_level} risk ({self.score})'
