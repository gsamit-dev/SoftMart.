from django.contrib import admin

from .models import FraudAssessment, Order, OrderItem, Review


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ('product', 'quantity', 'unit_price', 'license_type')


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'total_amount', 'status', 'created_at')
    list_filter = ('status',)
    search_fields = ('id', 'user__email')
    inlines = (OrderItemInline,)


admin.site.register(Review)
@admin.register(FraudAssessment)
class FraudAssessmentAdmin(admin.ModelAdmin):
    list_display = ('order', 'score', 'risk_level', 'reviewed', 'created_at')
    list_filter = ('risk_level', 'reviewed', 'created_at')
    search_fields = ('order__id', 'order__user__email')
    readonly_fields = ('order', 'score', 'risk_level', 'reasons', 'created_at')

    actions = ('mark_reviewed',)

    @admin.action(description='Mark selected fraud assessments as reviewed')
    def mark_reviewed(self, request, queryset):
        queryset.update(reviewed=True)
