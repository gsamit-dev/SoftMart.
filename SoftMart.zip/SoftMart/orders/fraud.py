from datetime import timedelta

from django.utils import timezone

from .models import FraudAssessment, Order


def assess_order_risk(order, quantity):
    now = timezone.now()
    score = 0
    reasons = []
    recent_attempts = Order.objects.filter(
        user=order.user, created_at__gte=now - timedelta(hours=1)
    ).exclude(pk=order.pk).count()
    recent_cancellations = Order.objects.filter(
        user=order.user, status='cancelled', created_at__gte=now - timedelta(days=1)
    ).count()
    if recent_attempts >= 4:
        score += 35
        reasons.append('Multiple checkout attempts in one hour')
    if recent_cancellations >= 3:
        score += 30
        reasons.append('Repeated order cancellations in one day')
    if quantity >= 5:
        score += 20
        reasons.append('Unusually large software quantity')
    if order.total_amount >= 50000:
        score += 35
        reasons.append('Unusually high order amount')
    if order.user.created_at and order.user.created_at >= now - timedelta(hours=24):
        score += 15
        reasons.append('Recently created account')
    score = min(score, 100)
    level = 'high' if score >= 60 else 'review' if score >= 30 else 'low'
    return FraudAssessment.objects.create(order=order, score=score, risk_level=level, reasons=reasons)
