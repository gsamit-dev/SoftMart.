from decimal import Decimal

from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.test import TestCase
from django.urls import reverse

from cart.models import Cart, CartItem
from catalog.models import Category, License, Product
from orders.models import Order


class CheckoutFlowTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            email='buyer@example.com', username='buyer', password='strong-password-123', phone_number='01700000000'
        )
        category = Category.objects.create(name='Productivity', slug='productivity')
        self.product = Product.objects.create(
            title='Office Suite', slug='office-suite', description='Test product', category=category,
            price=Decimal('25.00'), stock=1,
        )
        self.license = License.objects.create(
            product=self.product, key_hash=make_password('AAAA-BBBB-CCCC'), key_preview='AAAA-…-CCCC'
        )
        cart = Cart.objects.create(user=self.user)
        CartItem.objects.create(cart=cart, product=self.product, quantity=1)
        self.client.login(email='buyer@example.com', password='strong-password-123')

    def test_checkout_reserves_inventory_and_payment_assigns_license(self):
        response = self.client.post(reverse('orders:checkout'))
        self.assertRedirects(response, reverse('payments:checkout', args=[1]))

        order = Order.objects.get()
        self.product.refresh_from_db()
        self.license.refresh_from_db()
        self.assertEqual(self.product.stock, 0)
        self.assertEqual(self.license.status, 'reserved')
        self.assertEqual(self.license.order, order)

        response = self.client.post(reverse('payments:checkout', args=[order.id]))
        self.assertRedirects(response, reverse('dashboard:home'))
        self.license.refresh_from_db()
        self.assertEqual(self.license.status, 'assigned')
        self.assertEqual(self.license.owner, self.user)

    def test_cancelling_a_pending_order_releases_stock_and_license(self):
        self.client.post(reverse('orders:checkout'))
        order = Order.objects.get()

        response = self.client.post(reverse('orders:cancel', args=[order.id]))
        self.assertRedirects(response, reverse('orders:history'))
        self.product.refresh_from_db()
        self.license.refresh_from_db()
        order.refresh_from_db()
        self.assertEqual(order.status, 'cancelled')
        self.assertEqual(self.product.stock, 1)
        self.assertEqual(self.license.status, 'available')
        self.assertIsNone(self.license.order)
