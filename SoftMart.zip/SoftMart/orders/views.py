from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import FileResponse, Http404
from django.db import transaction
from django.db.models import Count, F
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from cart.models import Cart
from catalog.models import License, Product
from orders.models import Order, OrderItem
from payments.models import Payment
from .fraud import assess_order_risk


@login_required
def checkout_view(request):
    cart = Cart.objects.filter(user=request.user).first()
    if not cart or not cart.items.exists():
        return redirect('catalog:products')
    if request.method == 'POST':
        with transaction.atomic():
            items = list(cart.items.select_related('product'))
            locked_products = {
                product.id: product
                for product in Product.objects.select_for_update().filter(
                    id__in=[item.product_id for item in items], status='published'
                )
            }
            for item in items:
                product = locked_products.get(item.product_id)
                if not product or item.quantity > product.stock:
                    return render(request, 'orders/checkout.html', {
                        'cart': cart,
                        'error': f'{item.product.title} no longer has enough stock.',
                    })
                if License.objects.select_for_update().filter(
                    product=product, status='available'
                ).count() < item.quantity:
                    return render(request, 'orders/checkout.html', {
                        'cart': cart,
                        'error': f'{item.product.title} does not have enough license inventory.',
                    })
            order = Order.objects.create(
                user=request.user,
                total_amount=sum((item.product.get_price() * item.quantity) for item in items),
            )
            assessment = assess_order_risk(order, sum(item.quantity for item in items))
            if assessment.risk_level == 'high':
                order.status = 'cancelled'
                order.save(update_fields=['status', 'updated_at'])
                return render(request, 'orders/checkout.html', {
                    'cart': cart,
                    'error': 'This order was held for a security review. Your inventory was not reserved and no payment was taken. Please contact support.',
                })
            for item in items:
                product = locked_products[item.product_id]
                OrderItem.objects.create(
                    order=order,
                    product=product,
                    quantity=item.quantity,
                    unit_price=product.get_price(),
                    license_type=product.license_type,
                )
                reserved_licenses = list(License.objects.select_for_update().filter(
                    product=product, status='available'
                ).order_by('id')[:item.quantity])
                License.objects.filter(id__in=[license.id for license in reserved_licenses]).update(
                    status='reserved', order=order
                )
                product.stock -= item.quantity
                product.save(update_fields=['stock', 'updated_at'])
            Payment.objects.create(order=order, user=request.user, amount=order.total_amount, status='pending')
            cart.items.all().delete()
        return redirect('payments:checkout', order_id=order.id)
    return render(request, 'orders/checkout.html', {'cart': cart})


@login_required
def order_history_view(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'orders/history.html', {'orders': orders})


@login_required
def download_order_item_view(request, order_item_id):
    from django.shortcuts import get_object_or_404
    from orders.models import OrderItem
    item = get_object_or_404(
        OrderItem.objects.select_related('order', 'product'),
        pk=order_item_id, order__user=request.user, order__status__in=['paid', 'completed'],
    )
    if not item.product.file:
        raise Http404('Download file is not available.')
    try:
        download = item.product.file.open('rb')
    except (FileNotFoundError, OSError):
        raise Http404('Download file is not available.')
    return FileResponse(download, as_attachment=True, filename=item.product.file.name.rsplit('/', 1)[-1])


@login_required
@require_POST
def cancel_order_view(request, order_id):
    with transaction.atomic():
        order = get_object_or_404(
            Order.objects.select_for_update(), id=order_id, user=request.user, status='pending'
        )
        reserved = License.objects.select_for_update().filter(order=order, status='reserved')
        restock_counts = reserved.values('product_id').annotate(quantity=Count('id'))
        for row in restock_counts:
            Product.objects.filter(id=row['product_id']).update(stock=F('stock') + row['quantity'])
        reserved.update(status='available', order=None)
        Payment.objects.filter(order=order, status='pending').update(status='failed')
        order.status = 'cancelled'
        order.save(update_fields=['status', 'updated_at'])
    messages.info(request, 'Order cancelled and reserved licenses released.')
    return redirect('orders:history')
