"""WSGI config for the SoftMart project."""

import os

from django.core.wsgi import get_wsgi_application


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'SoftMart.settings')

application = get_wsgi_application()
