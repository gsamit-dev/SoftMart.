from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models
from django.urls import reverse
from django.utils.text import slugify


class Category(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=50, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = 'Categories'

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name) or 'category'
            self.slug = base_slug
            suffix = 2
            while Category.objects.exclude(pk=self.pk).filter(slug=self.slug).exists():
                self.slug = f'{base_slug[:45]}-{suffix}'
                suffix += 1
        super().save(*args, **kwargs)


class Product(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('published', 'Published'),
        ('archived', 'Archived'),
    ]
    OPERATING_SYSTEM_CHOICES = [
        ('windows', 'Windows'),
        ('mac', 'Mac'),
        ('linux', 'Linux'),
        ('multi', 'Multi-platform'),
    ]

    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True, blank=True)
    short_description = models.CharField(max_length=220, blank=True)
    description = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products')
    seller = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True, related_name='products')
    brand = models.CharField(max_length=100, blank=True)
    version = models.CharField(max_length=50, blank=True)
    license_type = models.CharField(max_length=100, default='Lifetime')
    duration_days = models.PositiveIntegerField(default=365)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    discount_price = models.DecimalField(max_digits=10, decimal_places=2, default=0, validators=[MinValueValidator(0)])
    stock = models.PositiveIntegerField(default=1)
    operating_system = models.CharField(max_length=50, choices=OPERATING_SYSTEM_CHOICES, default='windows')
    image = models.ImageField(upload_to='products/', blank=True, null=True)
    file = models.FileField(upload_to='products/files/', blank=True, null=True, help_text='Upload the application file (ZIP, EXE, etc.)')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='published')
    is_featured = models.BooleanField(default=False)
    rating = models.FloatField(default=0)
    rating_count = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        constraints = [
            models.CheckConstraint(
                condition=(
                    models.Q(price__gte=0)
                    & models.Q(discount_price__gte=0)
                    & (models.Q(discount_price=0) | models.Q(discount_price__lte=models.F('price')))
                ),
                name='catalog_valid_product_prices',
            ),
        ]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.title) or 'product'
            self.slug = base_slug
            suffix = 2
            while Product.objects.exclude(pk=self.pk).filter(slug=self.slug).exists():
                self.slug = f'{base_slug[:45]}-{suffix}'
                suffix += 1
        super().save(*args, **kwargs)

    def get_price(self):
        if self.discount_price and self.discount_price > 0:
            return self.discount_price
        return self.price

    def clean(self):
        super().clean()
        if self.discount_price and self.discount_price > self.price:
            raise ValidationError({'discount_price': 'Discount price cannot exceed the regular price.'})

    def get_discount_percent(self):
        if not self.price or self.price == 0:
            return 0
        if self.discount_price and self.discount_price > 0:
            return int(((self.price - self.discount_price) / self.price) * 100)
        return 0

    def get_absolute_url(self):
        return reverse('catalog:product_detail', kwargs={'slug': self.slug})


class ProductImage(models.Model):
    product = models.ForeignKey(Product, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='products/gallery/')

    def __str__(self):
        return f'{self.product.title} image'


class ProductFeature(models.Model):
    product = models.ForeignKey(Product, related_name='features', on_delete=models.CASCADE)
    text = models.CharField(max_length=200)

    def __str__(self):
        return self.text


class License(models.Model):
    STATUS_CHOICES = [('available', 'Available'), ('reserved', 'Reserved'), ('assigned', 'Assigned'), ('used', 'Used'), ('expired', 'Expired')]
    product = models.ForeignKey(Product, related_name='licenses', on_delete=models.CASCADE)
    key_hash = models.CharField(max_length=255)
    key_preview = models.CharField(max_length=40, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name='licenses')
    order = models.ForeignKey('orders.Order', null=True, blank=True, on_delete=models.SET_NULL, related_name='licenses')
    issued_at = models.DateTimeField(auto_now_add=True)
    used_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.key_preview or self.key_hash


class Wishlist(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='wishlist', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, related_name='wishlists', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'product')
