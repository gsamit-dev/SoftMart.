from django.contrib import admin

from .models import Category, License, Product, ProductFeature, ProductImage, Wishlist


class ProductFeatureInline(admin.TabularInline):
    model = ProductFeature
    extra = 1


class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 0


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'price', 'discount_price', 'stock', 'status', 'is_featured')
    list_filter = ('status', 'category', 'operating_system', 'is_featured')
    search_fields = ('title', 'brand', 'slug')
    prepopulated_fields = {'slug': ('title',)}
    inlines = (ProductFeatureInline, ProductImageInline)


@admin.register(License)
class LicenseAdmin(admin.ModelAdmin):
    list_display = ('key_preview', 'product', 'status', 'owner', 'order', 'issued_at')
    list_filter = ('status', 'product')
    search_fields = ('key_preview', 'product__title', 'owner__email')
    readonly_fields = ('owner', 'order', 'issued_at', 'used_at')


admin.site.register(Category)
admin.site.register(Wishlist)
