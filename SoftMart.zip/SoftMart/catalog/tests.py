from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from orders.models import Order, OrderItem, Review

from .models import Category, Product


class SellerAndReviewTests(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name='Utilities', slug='utilities')
        self.seller = get_user_model().objects.create_user(
            email='seller@example.com', username='seller', password='strong-password-123',
            phone_number='01900000000', role='seller',
        )
        self.customer = get_user_model().objects.create_user(
            email='customer@example.com', username='customer', password='strong-password-123',
            phone_number='01600000000', role='customer',
        )

    def test_seller_can_upload_and_archive_own_product(self):
        self.client.login(email='seller@example.com', password='strong-password-123')
        response = self.client.post(reverse('sellers:product_add'), {
            'title': 'Backup Tool', 'short_description': 'Back up files', 'description': 'Full test description',
            'category': self.category.id, 'license_type': 'Lifetime', 'duration_days': 365,
            'price': '30.00', 'discount_price': '20.00', 'stock': 3,
            'operating_system': 'windows', 'status': 'published',
        })
        self.assertRedirects(response, reverse('sellers:products'))
        product = Product.objects.get(title='Backup Tool')
        self.assertEqual(product.seller, self.seller)
        self.assertEqual(product.get_price(), Decimal('20.00'))

        response = self.client.post(reverse('sellers:product_archive', args=[product.id]))
        self.assertRedirects(response, reverse('sellers:products'))
        product.refresh_from_db()
        self.assertEqual(product.status, 'archived')

    def test_only_a_customer_who_bought_the_product_can_review(self):
        product = Product.objects.create(
            title='Cleaner', slug='cleaner', description='Test product', category=self.category,
            seller=self.seller, price=Decimal('10.00'), stock=1,
        )
        order = Order.objects.create(user=self.customer, total_amount=Decimal('10.00'), status='paid')
        OrderItem.objects.create(order=order, product=product, quantity=1, unit_price=Decimal('10.00'))
        self.client.login(email='customer@example.com', password='strong-password-123')

        response = self.client.post(reverse('catalog:submit_review', args=[product.slug]), {
            'rating': '5', 'comment': 'Very useful.',
        })
        self.assertRedirects(response, reverse('catalog:product_detail', args=[product.slug]))
        self.assertEqual(Review.objects.get(product=product, user=self.customer).rating, 5)
        product.refresh_from_db()
        self.assertEqual(product.rating, 5)
