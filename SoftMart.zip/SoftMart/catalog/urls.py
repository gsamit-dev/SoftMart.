from django.urls import path

from .views import home_view, product_detail_view, product_list_view, submit_review_view, support_chat_view

app_name = 'catalog'

urlpatterns = [
    path('', home_view, name='home'),
    path('support/chat/', support_chat_view, name='support_chat'),
    path('products/', product_list_view, name='products'),
    path('products/<slug:slug>/', product_detail_view, name='product_detail'),
    path('products/<slug:slug>/review/', submit_review_view, name='submit_review'),
]
