from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Avg, Count, Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from orders.models import Order, Review
from .forms import ReviewForm
from .models import Category, Product
from products.ai_services import analyze_review_sentiment, personalize_queryset, recommended_soft_products
from products.ai_services import answer_support_message


def home_view(request):
    categories = Category.objects.filter(is_active=True)[:8]
    featured_products = Product.objects.filter(status='published').order_by('-rating')[:8]
    # import here to avoid circular import
    from products.models import SoftProduct
    soft_products = SoftProduct.objects.filter(status='published').select_related('category')[:8]
    recommended_products = recommended_soft_products(request.user)
    context = {
        'categories': categories,
        'featured_products': featured_products,
        'soft_products': soft_products,
        'recommended_products': recommended_products,
    }
    return render(request, 'home.html', context)


def support_chat_view(request):
    conversation = request.session.get('support_chat', [])
    if request.GET.get('clear') == '1':
        request.session['support_chat'] = []
        return redirect('catalog:support_chat')
    if request.method == 'POST':
        question = request.POST.get('message', '').strip()[:500]
        if question:
            conversation.extend([
                {'role': 'user', 'text': question},
                {'role': 'assistant', 'text': answer_support_message(question)},
            ])
            request.session['support_chat'] = conversation[-12:]
    return render(request, 'support/chatbot.html', {'conversation': request.session.get('support_chat', [])})


def product_list_view(request):
    products = Product.objects.filter(status='published')
    category_slug = request.GET.get('category')
    search = request.GET.get('q', '').strip()
    if category_slug:
        products = products.filter(category__slug=category_slug)
    if search:
        products = products.filter(
            Q(title__icontains=search) | Q(brand__icontains=search)
            | Q(short_description__icontains=search) | Q(description__icontains=search)
            | Q(category__name__icontains=search)
        )
    min_price = request.GET.get('min_price', '').strip()
    max_price = request.GET.get('max_price', '').strip()
    sort = request.GET.get('sort', 'recommended')
    try:
        if min_price:
            from decimal import Decimal, InvalidOperation
            value = Decimal(min_price)
            if value.is_finite() and value >= 0:
                products = products.filter(
                    Q(discount_price__gte=value, discount_price__gt=0)
                    | Q(discount_price=0, price__gte=value)
                )
    except (InvalidOperation, ValueError):
        min_price = ''
    try:
        if max_price:
            from decimal import Decimal, InvalidOperation
            value = Decimal(max_price)
            if value.is_finite() and value >= 0:
                products = products.filter(
                    Q(discount_price__lte=value, discount_price__gt=0)
                    | Q(discount_price=0, price__lte=value)
                )
    except (InvalidOperation, ValueError):
        max_price = ''
    ordering = {'newest': '-created_at', 'price_low': 'price', 'price_high': '-price', 'rating': '-rating'}
    if sort not in ordering and sort != 'recommended':
        sort = 'recommended'
    if sort == 'recommended':
        products = personalize_queryset(products, request.user)
    else:
        products = products.order_by(ordering.get(sort, '-created_at'))
    return render(request, 'catalog/products.html', {
        'products': products, 'categories': Category.objects.filter(is_active=True),
        'q': search, 'min_price': min_price, 'max_price': max_price,
        'sort': sort, 'active_category': category_slug or '',
    })


def product_detail_view(request, slug):
    product = get_object_or_404(Product, slug=slug, status='published')
    related = Product.objects.filter(category=product.category, status='published').exclude(id=product.id)[:4]
    can_review = (
        request.user.is_authenticated
        and request.user.role == 'customer'
        and Order.objects.filter(user=request.user, status__in=['paid', 'completed'], items__product=product).exists()
    )
    existing_review = Review.objects.filter(product=product, user=request.user).first() if can_review else None
    reviews = list(product.reviews.select_related('user').order_by('-created_at'))
    sentiment_counts = {'Positive': 0, 'Neutral': 0, 'Negative': 0}
    for review in reviews:
        review.sentiment_label = analyze_review_sentiment(review.comment)['label']
        sentiment_counts[review.sentiment_label] += 1
    return render(request, 'catalog/product_detail.html', {
        'product': product,
        'related_products': related,
        'reviews': reviews,
        'sentiment_counts': sentiment_counts,
        'can_review': can_review,
        'review_form': ReviewForm(instance=existing_review),
    })


@login_required
@require_POST
def submit_review_view(request, slug):
    product = get_object_or_404(Product, slug=slug, status='published')
    if request.user.role != 'customer' or not Order.objects.filter(
        user=request.user, status__in=['paid', 'completed'], items__product=product
    ).exists():
        messages.error(request, 'Only customers who purchased this product can leave a review.')
        return redirect('catalog:product_detail', slug=product.slug)

    review, _ = Review.objects.get_or_create(product=product, user=request.user)
    form = ReviewForm(request.POST, instance=review)
    if form.is_valid():
        form.save()
        summary = product.reviews.aggregate(average=Avg('rating'), total=Count('id'))
        product.rating = summary['average'] or 0
        product.rating_count = summary['total']
        product.save(update_fields=['rating', 'rating_count', 'updated_at'])
        messages.success(request, 'Your review has been saved.')
    else:
        messages.error(request, 'Please provide a valid rating and review.')
    return redirect('catalog:product_detail', slug=product.slug)
