# Software license activation API

Purchased app licenses can be bound to a stable device identifier. Send requests over HTTPS from the installed software.

After validated payment, the buyer can view the license key on the purchased software page. The server never stores the plaintext key: it derives a stable key from the server secret and purchase ID, and stores a SHA-256 hash for lookup. Buyers should keep the key private.

## Activate or renew

`POST /api/licenses/activate/`

First request:

```json
{
  "license_key": "PURCHASED-LICENSE-KEY",
  "device_id": "stable-installation-fingerprint"
}
```

The customer receives a six-digit code by email. Send the same request again with `otp` added. A successful response contains `status: active` and an `expires_at` timestamp. If the customer switches devices, the new device must pass email OTP verification; authorization then moves to that device and the previous device stops validating. After expiry, repeat the OTP flow to renew for another year.

## Validate on software start

`POST /api/licenses/validate/`

```json
{
  "license_key": "PURCHASED-LICENSE-KEY",
  "device_id": "stable-installation-fingerprint"
}
```

Continue launching the software only when the API returns HTTP 200 and `status: valid`. The server stores only a SHA-256 hash of the device identifier. Do not send a changing identifier; it must remain stable for that installation.
